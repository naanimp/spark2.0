package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

public class DynCommDriver {
    static int GROUPS_TO_REPORT = 10;
    static boolean DETAILED_TIMING = true;
    static boolean ONE_BASED_TIMELINE = false;
    static boolean PROMPT_FOR_FILENAME = true;
    static String INPUT_FILENAME = "../IO/new_graph/scalability_time_0100_run000.txt";
    static boolean PR_USE_PRUNING = true;
    static boolean PR_USE_GROUPS = true;
    static boolean PR_ONLY_PRUNING = false;
    static boolean PR_COMPUTE_ALL_EIGS = false;
    static double PR_ESTIMATE = 0.016;
    static boolean PR_CALC_ESTIMATE = true;
    static int PR_ESTIMATION_HASH_TRIES = 20;
    static int PR_ESTIMATION_INTERVALS = 10;
    static int HASH_BANDS = 1;
    static int HASH_ROWS_PER_BAND = 2;
    static boolean HASH_USE_LOG_SCALES = true;
    static int HASH_LOG_SCALE_MULTIPLIER = 5;
    static boolean RW_USE_TEMPORAL_RW = false;
    static double RW_ALPHA = 0.15;
    static double RW_BETA = 0.25;
    static int RW_BINS_TO_EXAMINE = 20;

    public static SparkSession getSparkSession(){
        SparkSession spark = SparkSession.builder().appName("DynCommDriver").master("local[1]").config("spark.driver.memory","6G").getOrCreate();
        return spark;
    }

    public static JavaSparkContext getJsc(){
        return JavaSparkContext.fromSparkContext(getSparkSession().sparkContext());
    }

    public static void read_parameter_file() {
        Scanner sc = null;
        try {
            sc = new Scanner(new File("params.txt"));
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.length() == 0 || line.charAt(0) == '#') continue;
                String[] parts = line.split("=");
                if (parts.length != 2) {
                    System.err.println("Invalid line in params file: " + line);
                    System.err.println("\tContinuing...");
                    continue;
                }
                if (parts[1].length() == 0) continue;
                try {
                    int i;
                    if (parts[0].equals("GROUPS_TO_REPORT")) {
                        GROUPS_TO_REPORT = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("DETAILED_TIMING")) {
                        DETAILED_TIMING = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("ONE_BASED_TIMELINE")) {
                        ONE_BASED_TIMELINE = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PROMPT_FOR_FILENAME")) {
                        PROMPT_FOR_FILENAME = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("INPUT_FILENAME")) {
                        INPUT_FILENAME = parts[1];
                        continue;
                    }
                    if (parts[0].equals("PR_USE_PRUNING")) {
                        PR_USE_PRUNING = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PR_USE_GROUPS")) {
                        PR_USE_GROUPS = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PR_ONLY_PRUNING")) {
                        PR_ONLY_PRUNING = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PR_COMPUTE_ALL_EIGS")) {
                        PR_COMPUTE_ALL_EIGS = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PR_ESTIMATE")) {
                        double d;
                        PR_ESTIMATE = d = Double.parseDouble(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("PR_CALC_ESTIMATE")) {
                        PR_CALC_ESTIMATE = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("PR_ESTIMATION_HASH_TRIES")) {
                        PR_ESTIMATION_HASH_TRIES = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("PR_ESTIMATION_INTERVALS")) {
                        PR_ESTIMATION_INTERVALS = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("HASH_BANDS")) {
                        HASH_BANDS = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("HASH_ROWS_PER_BAND")) {
                        HASH_ROWS_PER_BAND = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("HASH_USE_LOG_SCALES")) {
                        HASH_USE_LOG_SCALES = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("HASH_LOG_SCALE_MULTIPLIER")) {
                        HASH_LOG_SCALE_MULTIPLIER = i = Integer.parseInt(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("RW_USE_TEMPORAL_RW")) {
                        RW_USE_TEMPORAL_RW = parts[1].charAt(0) == 't' || parts[1].charAt(0) == 'T';
                        continue;
                    }
                    if (parts[0].equals("RW_ALPHA")) {
                        double d;
                        RW_ALPHA = d = Double.parseDouble(parts[1]);
                        continue;
                    }
                    if (parts[0].equals("RW_BETA")) {
                        double d;
                        RW_BETA = d = Double.parseDouble(parts[1]);
                        continue;
                    }
                    if (!parts[0].equals("RW_BINS_TO_EXAMINE")) continue;
                    RW_BINS_TO_EXAMINE = i = Integer.parseInt(parts[1]);
                }
                catch (NumberFormatException e) {
                    System.err.println("Invalid line in params file: " + line);
                }
            }
            sc.close();
        }
        catch (FileNotFoundException e) {
            System.err.println("params.txt file is missing; using default parameters.");
            return;
        }
    }

    public static void multiscale_driver(String fileName) {
        PruneContainer pc;
        int i;
        TGraph g = new TGraph(".", ".");
        Path basepath = FileSystems.getDefault().getPath(".");
        System.out.println(fileName);
        TreeSet<Integer> possible_pivots = new TreeSet<>();
        Instant overall_start = Instant.now();
        if (DETAILED_TIMING) {
            System.out.println("\t% Begin PHASR: " + Duration.between(overall_start, Instant.now()).getSeconds());
            System.out.println("\t%%% Begin import: " + Duration.between(overall_start, Instant.now()).getSeconds());
        }
        g.importGraph(fileName, false, ONE_BASED_TIMELINE, true);
        if (DETAILED_TIMING) {
            System.out.println("\t%%%%%% Finished import: " + Duration.between(overall_start, Instant.now()).getSeconds());
        }
        int big = g.vertexSet().last();
        int timeline = g.maxTime() + 1;
        int maxScale = g.maxTime() + 1;
        if (PR_USE_PRUNING) {
            int i2;
            if (DETAILED_TIMING) {
                System.out.println("\t%%% Begin pruning: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            String eigstr = PR_COMPUTE_ALL_EIGS ? "ALL eigenvalues" : "selected eigenvalues";
            String grstr = PR_USE_GROUPS ? "will" : "will NOT";
            System.out.println("Pruning will compute " + eigstr + " and " + grstr + " try to prune groups of intervals.");
            RealPruneContainer.FAST_ESTIMATE = PR_CALC_ESTIMATE;
            RealPruneContainer.HASH_ATTEMPTS = PR_ESTIMATION_HASH_TRIES;
            RealPruneContainer.INTERVALS_TO_CHECK = PR_ESTIMATION_INTERVALS;
            pc = new RealPruneContainer(g, timeline, basepath, fileName, ONE_BASED_TIMELINE, PR_ESTIMATE, DETAILED_TIMING, PR_USE_GROUPS, PR_COMPUTE_ALL_EIGS);
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%% Finished precomputation: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            pc.improveEstimate(PR_ESTIMATE);
            pc.updatePruning();
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%%%%% Volume computation time: " + Prune.volTime.getSeconds());
                System.out.println("\t%%%%%%%%% Solver computation time: " + Prune.solveTime.getSeconds());
                System.out.println("\t%%%%%% Finished w/ PruneContainer: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            if (DETAILED_TIMING) {
                System.out.println("\t%%% Finished pruning: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            pc.printPruningStats();
            if (HASH_USE_LOG_SCALES) {
                for (i2 = DynCommDriver.HASH_LOG_SCALE_MULTIPLIER; i2 < maxScale; i2 *= DynCommDriver.HASH_LOG_SCALE_MULTIPLIER) {
                    if (pc.isPrunedDuration(i2 - 1)) continue;
                    possible_pivots.add(2 * maxScale / i2);
                }
            } else {
                for (i2 = maxScale; i2 > 1; --i2) {
                    if (pc.isPrunedDuration(i2 - 1)) continue;
                    possible_pivots.add(2 * maxScale / i2);
                }
            }
            if (!pc.isPrunedDuration(maxScale - 1)) {
                possible_pivots.add(1);
            }
        } else {
            int i3;
            System.out.println("Skipping pruning");
            pc = new DummyPruneContainer();
            if (HASH_USE_LOG_SCALES) {
                for (i3 = DynCommDriver.HASH_LOG_SCALE_MULTIPLIER; i3 < maxScale; i3 *= DynCommDriver.HASH_LOG_SCALE_MULTIPLIER) {
                    possible_pivots.add(2 * maxScale / i3);
                }
            } else {
                for (i3 = maxScale; i3 > 1; --i3) {
                    possible_pivots.add(2 * maxScale / i3);
                }
            }
            possible_pivots.add(1);
        }
        if (PR_ONLY_PRUNING) {
            System.out.println();
            return;
        }
        System.out.println("Max scale: " + maxScale);
        System.out.println("Possible pivots: " + possible_pivots);
        ArrayList<Double> bestCond = new ArrayList<Double>(GROUPS_TO_REPORT);
        ArrayList<Double> bestCondHashScore = new ArrayList<Double>(GROUPS_TO_REPORT);
        ArrayList<Integer> bestSetRank = new ArrayList<Integer>(GROUPS_TO_REPORT);
        ArrayList<TreeSet<Integer>> bestSet = new ArrayList<TreeSet<Integer>>(GROUPS_TO_REPORT);
        ArrayList<Integer[]> bestTimes = new ArrayList<Integer[]>(GROUPS_TO_REPORT);
        for (i = 0; i < GROUPS_TO_REPORT; ++i) {
            bestCond.add(1.0);
            bestCondHashScore.add(0.0);
            bestSetRank.add(RW_BINS_TO_EXAMINE + 1);
            bestSet.add(new TreeSet());
            bestTimes.add(new Integer[2]);
        }
        Iterator iterator = possible_pivots.descendingSet().iterator();
        while (iterator.hasNext()) {
            int target;
            int timebits = (Integer)iterator.next();
            System.out.println("\tWorking with " + timebits + " pivots.");
            Instant partitionStart = Instant.now();
            if (DETAILED_TIMING) {
                System.out.println("\t%%% Begin single-scale PHASR (" + timebits + " pivots): " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            if ((target = 2 * (g.maxTime() - g.minTime() + 1) / timebits) >= timeline) {
                target = timeline - 1;
            }
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%% Begin hashing: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            TemporalWeightedMinhashGadget hasher = new TemporalWeightedMinhashGadget(big + 1, HASH_BANDS, HASH_ROWS_PER_BAND, timebits, target);
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%%%%% Finished RNG: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            TreeMap<Double, TreeSet<TemporalNode>> hashResult = hasher.performHashing(g, target, pc, RW_USE_TEMPORAL_RW);
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%% Finished hashing: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            if (hashResult.size() == 0) {
                System.out.println("\t\tNO HASHING BINS AT THIS SCALE.");
                continue;
            }
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%% Begin random walks: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            Double hashScore = hashResult.lastKey();
            int counter = 0;
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%%%%% Finished RW setup: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            boolean pruningCheck = false;


            /*
                 This part can't be parallelized  as it has dependency on previous state in while loop

             */
            while (hashScore != null && counter < RW_BINS_TO_EXAMINE) {
                ++counter;
                TreeSet<TemporalNode> seeds = hashResult.get(hashScore);
                boolean skip = false;
                if (pruningCheck) {
                    int range = seeds.last().getTime() - seeds.first().getTime();
                    for (Integer time : TemporalNode.extractTimes(seeds)) {
                        if (!pc.isPruned(time, range)) continue;
                        skip = true;
                        break;
                    }
                }
                if (!skip) {
                    TreeMap tempMap;
                    TreeSet<Integer> verts = null;
                    Integer[] times = TemporalNode.span(seeds);
                    TreeSet<TemporalNode> swipeResult = null;
                    double[] conductance = new double[1];
                    if (RW_USE_TEMPORAL_RW) {
                        tempMap = g.temporalRWRBeta(seeds, RW_ALPHA, RW_BETA, false, true, true);
                        swipeResult = g.AndersenSwipes(tempMap, conductance, true, fileName, counter);
                    } else {
                        tempMap = g.standardRWR(TemporalNode.extractVertices(seeds), RW_ALPHA, false, true, seeds.first().getTime(), seeds.last().getTime() + 1);
                        verts = g.standardSweeps(tempMap, conductance, true, seeds.first().getTime(), seeds.last().getTime() + 1);
                    }
                    if (conductance[0] < bestCond.get(GROUPS_TO_REPORT - 1)) {
                        int p1;
                        for (p1 = DynCommDriver.GROUPS_TO_REPORT - 1; p1 > 0 && conductance[0] < bestCond.get(p1 - 1); --p1) {
                            bestCond.set(p1, bestCond.get(p1 - 1));
                            bestCondHashScore.set(p1, bestCond.get(p1 - 1));
                            bestSetRank.set(p1, bestSetRank.get(p1 - 1));
                            bestSet.set(p1, (TreeSet)bestSet.get(p1 - 1));
                            bestTimes.set(p1, bestTimes.get(p1 - 1));
                        }
                        if (RW_USE_TEMPORAL_RW) {
                            verts = TemporalNode.extractVertices(swipeResult);
                            times = TemporalNode.span(swipeResult);
                        }
                        bestCond.set(p1, conductance[0]);
                        bestCondHashScore.set(p1, hashScore);
                        bestSetRank.set(p1, counter);
                        bestSet.set(p1, verts);
                        bestTimes.set(p1, times);
                    }
                    if (pc.improveEstimate(conductance[0])) {
                        pruningCheck = true;
                    }
                }
                hashScore = hashResult.lowerKey(hashScore);
            }
            if (DETAILED_TIMING) {
                System.out.println("\t%%%%%% Finished random walks: " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            if (DETAILED_TIMING) {
                System.out.println("\t%%% End single-scale PHASR (" + timebits + " pivots): " + Duration.between(overall_start, Instant.now()).getSeconds());
            }
            long partitionDuration = Duration.between(partitionStart, Instant.now()).getSeconds();
            System.out.println("\tCompleted " + timebits + " pivots in " + partitionDuration + " seconds.");
        }
        if (DETAILED_TIMING) {
            System.out.println("\t%%%%%% Begin output: " + Duration.between(overall_start, Instant.now()).getSeconds());
        }
        System.out.println("Rank,Conductance,Vertices,Time1,Time2,List");
        for (i = 0; i < GROUPS_TO_REPORT; ++i) {
            System.out.format("%d,%f,%d,%d,%d,%s%n", i, bestCond.get(i), bestSet.get(i).size(), bestTimes.get(i)[0], bestTimes.get(i)[1], bestSet.get(i).toString());
        }
        if (DETAILED_TIMING) {
            System.out.println("\t\t%%%%%% Finished output: " + Duration.between(overall_start, Instant.now()).getSeconds());
        }
        long overallTime = Duration.between(overall_start, Instant.now()).getSeconds();
        System.out.println(fileName + " - Total execution time: " + overallTime + " seconds.");
        System.out.println();
    }

    public static void main(String[] args) {
        DynCommDriver.read_parameter_file();
        String fileName = INPUT_FILENAME;
        if (args.length > 0) {
            for (int i = 0; i < args.length; ++i) {
                DynCommDriver.multiscale_driver(args[i]);
            }
        } else {
            if (PROMPT_FOR_FILENAME) {
                System.out.println("Enter name of input file: ");
                Scanner sc = new Scanner(System.in);
                fileName = sc.nextLine();
            }
            DynCommDriver.multiscale_driver(fileName);
        }
    }
}

