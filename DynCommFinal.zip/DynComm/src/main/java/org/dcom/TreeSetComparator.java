package org.dcom;/*
 * Decompiled with CFR 0.146.
 */
import java.io.Serializable;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetComparator
implements Comparator<TreeSet<Integer>> , Serializable {
    @Override
    public int compare(TreeSet<Integer> s1, TreeSet<Integer> s2) {
        if (s1 == null) {
            if (s2 == null) {
                return 0;
            }
            return -1;
        }
        if (s2 == null) {
            return 1;
        }
        Iterator<Integer> i1 = s1.iterator();
        Iterator<Integer> i2 = s2.iterator();
        while (i1.hasNext() && i2.hasNext()) {
            int x2;
            int x1 = i1.next();
            if (x1 < (x2 = i2.next().intValue())) {
                return -1;
            }
            if (x1 <= x2) continue;
            return 1;
        }
        if (i1.hasNext()) {
            return 1;
        }
        if (i2.hasNext()) {
            return -1;
        }
        return 0;
    }
}

