package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import org.apache.spark.api.java.JavaRDD;
import scala.Tuple2;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.*;


class HashUtils implements Serializable {

    protected static ArrayList<TreeSet<TemporalNode>> splitBin(TreeSet<TemporalNode> bin) {
        ArrayList<TreeSet<TemporalNode>> result = new ArrayList<>();
        TreeSet<TemporalNode> curBin = new TreeSet<>();
        TemporalNode curNode = bin.first();
        Integer curTime = curNode.getTime();
        curBin.add(curNode);
        curNode = bin.higher(curNode);
        while (curNode != null) {
            if (curNode.getTime().equals(curTime + 1)) {
                curTime = curTime + 1;
            }
            if (!curNode.getTime().equals(curTime)) {
                result.add(curBin);
                curBin = new TreeSet();
                curTime = curNode.getTime();
            }
            curBin.add(curNode);
            curNode = bin.higher(curNode);
        }
        result.add(curBin);
        return result;
    }

    protected static Double scoreBin(TreeSet<TemporalNode> bin, int scale) {
        double full = TemporalNode.extractVertices(bin).size() * scale;
        return (double)bin.size() / full;
    }

    protected static Double scoreBin(TreeSet<TemporalNode> bin) {
        TreeSet<Integer> nodes = new TreeSet<Integer>();
        TreeSet<Integer> times = new TreeSet<Integer>();
        for (TemporalNode tn : bin) {
            nodes.add(tn.getNode());
            times.add(tn.getTime());
        }
        return (double)(nodes.size() * times.size() * bin.size()) * 1.0;
    }

    public static String pad(long k, int digits) {
        String s = String.format("%x", k);
        int n = digits - s.length();
        if (n > 0) {
            String z = new String(new char[n]).replace('\u0000', '0');
            s = z + s;
        }
        return s;
    }
}
public class TemporalWeightedMinhashGadget implements  Serializable {

    double[][][] r;
    double[][][] c;
    double[][][] beta;
    double[][] psi;
    ArrayList<Integer> mapping;
    transient Random rg;
    int size;
    int bands;
    int rows;
    int timebits;
    int target;

    public TemporalWeightedMinhashGadget(int size, int bands, int rows, int timebits) {
        this.r = new double[bands][rows][size];
        this.c = new double[bands][rows][size];
        this.beta = new double[bands][rows][size];
        this.psi = new double[bands][timebits];
        this.mapping = null;
        this.rg = new Random();
        this.size = size;
        this.bands = bands;
        this.rows = rows;
        for (int i = 0; i < bands; ++i) {
            for (int j = 0; j < rows; ++j) {
                for (int k = 0; k < size; ++k) {
                    this.r[i][j][k] = -1.0 * (Math.log(this.rg.nextDouble()) + Math.log(this.rg.nextDouble()));
                    this.c[i][j][k] = -1.0 * (Math.log(this.rg.nextDouble()) + Math.log(this.rg.nextDouble()));
                    this.beta[i][j][k] = this.rg.nextDouble();
                }
            }
            for (int p = 0; p < timebits; ++p) {
                this.psi[i][p] = this.rg.nextDouble();
            }
        }
        this.target = 200 / timebits;
    }

    public TemporalWeightedMinhashGadget(int size, int bands, int rows, int timebits, int target) {
        this(size, bands, rows, timebits);
        this.target = target;
    }


    public TreeMap<Double, TreeSet<TemporalNode>> performHashing(TGraph g) {
        return this.performHashing(g, 0, null);
    }

    public TreeMap<Double, TreeSet<TemporalNode>> performHashing(TGraph g, int scale) {
        return this.performHashing(g, scale, null, true);
    }

    public TreeMap<Double, TreeSet<TemporalNode>> performHashing(TGraph g, PruneContainer pc) {
        return this.performHashing(g, 0, pc, true);
    }

    public TreeMap<Double, TreeSet<TemporalNode>> performHashing(TGraph g, int scale, PruneContainer pc) {
        return this.performHashing(g, scale, pc, true);
    }

    public TreeMap<Double, TreeSet<TemporalNode>> performHashing(TGraph g, int scale, PruneContainer pc, boolean split) {
        TreeMap<Double, TreeSet<TemporalNode>> result = new TreeMap<Double, TreeSet<TemporalNode>>();
        TreeSet<TreeSet<TemporalNode>> bins = new TreeSet<TreeSet<TemporalNode>>(new TreeSetTNComparator());
        PrintStream pw = System.out;
        pw.print("Generating timebits... ");
        double[][] pivots = new double[this.size][this.timebits];
        int duration = g.maxTime() - g.minTime();
        for (int i = 0; i < this.bands; ++i) {
            for (int p = 0; p < this.timebits; ++p) {
                pivots[i][p] = (double)duration * this.psi[i][p] + (double)g.minTime().intValue();
            }
        }
        pw.println(" done.");
        int tl = (int)(Math.log(this.timebits) / Math.log(16.0) + 1.0);
        if (this.timebits < 16) {
            tl = 1;
        }
        int new_tl = tl;
        int digits = (int)(Math.log(this.size) / Math.log(16.0) + 1.0);
        if (this.mapping == null) {

            for (int bi = 0; bi < this.bands; ++bi) {
                List<Integer> times = new ArrayList<>();
                for (int curT = g.minTime(); curT < g.maxTime(); ++curT) {
                    if (pc != null && pc.isPruned(curT, target - 1)) continue;
                    times.add(curT);
                }

                /*
                Here we have parallelized all the times so that we can use hashing in parallel

                */

                JavaRDD<Integer> rdd = DynCommDriver.getJsc().parallelize(times);

                /*
                    All variable Here will  be serialized  and used fo computation
                 */
                int i = bi;
                double[][] ri = this.r[i];
                double[][] ci = this.c[i];
                double[][] betai = this.beta[i];
                int rows_count = this.rows;
                int timebits_count = this.timebits;
                /*
                    Here All the times map are being computed in parallel for hashing
                    Basically we are caculating all the tempNodes for which we will compute Hashing
                 */

                bins.addAll(rdd.flatMap(curT -> {
                    ArrayList<Tuple2<String, TreeSet<TemporalNode>>> tempNodes = new ArrayList<>();
                    for (TemporalNode tn2 : g.tNodes(curT)) {
                        TreeMap<Integer, Double> wMap = g.getWeightedNeighborhood(tn2);
                        if (wMap == null) continue;
                        StringBuilder sig = new StringBuilder();
                        for (int j = 0; j < rows_count; ++j) {
                            double minA = Double.POSITIVE_INFINITY;
                            String mh = "";
                            double maxW = Double.MIN_VALUE;
                            for (Integer k : wMap.keySet()) {
                                Double w = wMap.get(k);
                                if (w == null) continue;
                                if (w > maxW) {
                                    maxW = w;
                                }
                                int t = (int) Math.floor(Math.log(w) / ri[j][k] + betai[j][k]);
                                double y = Math.exp(ri[j][k] * ((double) t - betai[j][k]));
                                double a = ci[j][k] / (y * Math.exp(ri[j][k]));
                                if (!(a < minA)) continue;
                                minA = a;
                                mh = HashUtils.pad(k, digits) + String.format("%x", t);
                            }
                            sig.append(mh);
                        }
                        long timeHash = 0L;
                        for (int p = 0; p < timebits_count; ++p) {
                            timeHash *= 2L;
                            if (!((double) tn2.getTime() >= pivots[i][p])) continue;
                            ++timeHash;
                        }
                        sig.insert(0, HashUtils.pad(timeHash, new_tl));
                        TreeSet<TemporalNode> nodes = new TreeSet<>();
                        nodes.add(tn2);
                        tempNodes.add(new Tuple2<>(sig.toString(), nodes));

                    }
                    return tempNodes.iterator();


                }).mapToPair(x->x).reduceByKey((x,y) -> {
                    /*
                    This is the part where aggregation is going on . As it is Tree Set All the repeated element will
                    be removed


                     */
                    TreeSet<TemporalNode> nodes = new TreeSet<TemporalNode>();
                    nodes.addAll(x);
                    nodes.addAll(y);
                    return nodes;
                }).filter(x-> x._2.size() != 1).flatMap(x-> {

                    /*
                        This part will store all calculate the bins and remove unwanted things
                     */
                    List <TreeSet<TemporalNode>> tbins = new ArrayList<>();
                    if (split) {
                        ArrayList<TreeSet<TemporalNode>> splits = HashUtils.splitBin((x._2));
                        for (TreeSet<TemporalNode> bin : splits) {
                            if (bin.size() < 2) continue;
                            tbins.add(bin);
                        }
                    }
                    tbins.add(x._2);
                    return  tbins.iterator();
                }).collect());
            }
            pw.println(" done!");
            pw.print("Scoring bins... ");

            /*
                Finally As the bins are so small no point in calculating them in parallel.
             */
            for (TreeSet<TemporalNode> bin : bins) {
                if (scale == 0) {
                    result.put(HashUtils.scoreBin(bin), bin);
                    continue;
                }
                result.put(HashUtils.scoreBin(bin, scale), bin);
            }
            pw.println(" done!");
        }
        return result;
}

    public TreeMap<Double, TreeSet<TemporalNode>> performLimitedHash(TGraph g, int t1, int t2) {
        TreeMap<Double, TreeSet<TemporalNode>> result = new TreeMap<Double, TreeSet<TemporalNode>>();
        TreeSet<TreeSet<TemporalNode>> bins = new TreeSet<TreeSet<TemporalNode>>(new TreeSetTNComparator());
        double[][] pivots = new double[this.size][this.timebits];
        int duration = g.maxTime() - g.minTime();
        for (int i = 0; i < this.bands; ++i) {
            for (int p = 0; p < this.timebits; ++p) {
                pivots[i][p] = (double)duration * this.psi[i][p] + (double)g.minTime().intValue();
            }
        }
        int tl = (int)(Math.log(this.timebits) / Math.log(16.0) + 1.0);
        if (this.timebits < 16) {
            tl = 1;
        }
        int digits = (int)(Math.log(this.size) / Math.log(16.0) + 1.0);
        if (this.mapping == null) {
            for (int i = 0; i < this.bands; ++i) {
                Hashtable table = new Hashtable();
                for (int curT = t1; curT <= t2; ++curT) {
                    for (TemporalNode tn2 : g.tNodes(curT)) {
                        TreeMap<Integer, Double> wMap = g.getWeightedNeighborhood(tn2);
                        if (wMap == null) continue;
                        Object sig = "";
                        for (int j = 0; j < this.rows; ++j) {
                            double minA = Double.POSITIVE_INFINITY;
                            String mh = "";
                            double maxW = Double.MIN_VALUE;
                            for (Integer k : wMap.keySet()) {
                                Double w = wMap.get(k);
                                if (w == null) continue;
                                if (w > maxW) {
                                    maxW = w;
                                }
                                int t = (int)Math.floor(Math.log(w) / this.r[i][j][k] + this.beta[i][j][k]);
                                double y = Math.exp(this.r[i][j][k] * ((double)t - this.beta[i][j][k]));
                                double a = this.c[i][j][k] / (y * Math.exp(this.r[i][j][k]));
                                if (!(a < minA)) continue;
                                minA = a;
                                mh = HashUtils.pad(k.intValue(), digits) + String.format("%x", t);
                            }
                            sig = sig + mh;
                        }
                        long timeHash = 0L;
                        for (int p = 0; p < this.timebits; ++p) {
                            timeHash *= 2L;
                            if (!((double)tn2.getTime().intValue() >= pivots[i][p])) continue;
                            ++timeHash;
                        }
                        sig = String.valueOf(HashUtils.pad(timeHash, tl)) + sig;
                        TreeSet<TemporalNode> nodes = new TreeSet<TemporalNode>();
                        nodes.add(tn2);
                        if (table.containsKey(sig)) {
                            nodes.addAll((Collection)table.get(sig));
                        }
                        table.put(sig, nodes);
                    }
                }
                for (Object  key : table.keySet()) {
                    if (((TreeSet)table.get(key)).size() == 1) continue;
                    ArrayList<TreeSet<TemporalNode>> splits = HashUtils.splitBin((TreeSet)table.get(key));
                    for (TreeSet bin : splits) {
                        if (bin.size() < 2) continue;
                        bins.add(bin);
                    }
                }
                for (TreeSet<TemporalNode> bin : bins) {
                    result.put(HashUtils.scoreBin(bin), bin);
                }
            }
        }
        return result;
    }

}

