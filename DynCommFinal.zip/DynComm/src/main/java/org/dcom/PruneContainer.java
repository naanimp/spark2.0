package org.dcom;

/*
 * Decompiled with CFR 0.146.
 */
public abstract class PruneContainer {
    public abstract boolean improveEstimate(double var1);

    public abstract void updatePruning();

    public abstract boolean isPruned(int var1, int var2);

    public abstract boolean isPrunedDuration(int var1);

    public void printPruningStats() {
    }
}

