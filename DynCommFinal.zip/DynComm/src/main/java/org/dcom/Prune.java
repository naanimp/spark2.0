package org.dcom;/*
 * Decompiled with CFR 0.146.
 * 
 * Could not load the following classes:
 *  no.uib.cipr.matrix.Matrix
 *  no.uib.cipr.matrix.MatrixEntry
 *  no.uib.cipr.matrix.sparse.ArpackSym
 *  no.uib.cipr.matrix.sparse.ArpackSym$Ritz
 *  no.uib.cipr.matrix.sparse.LinkedSparseMatrix
 */

import no.uib.cipr.matrix.MatrixEntry;
import no.uib.cipr.matrix.sparse.ArpackSym;
import no.uib.cipr.matrix.sparse.LinkedSparseMatrix;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;


import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.io.*;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.function.IntToDoubleFunction;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;



/*
    This is simple Entry class for string the row matrix
    It is created so that that we can use the it in Serializable way
 */
class Entry implements  Serializable{
    int r;
    int c;
    double d;
    Entry(int r, int c, double d){
        this.r = r;
        this.c = c;
        this.d = d;
    }
}

/*
    This consist of All  the entry of Sparse Matrix.
    It will be just be used to Serialize the Data
 */
class SerialBlock implements Serializable {
    int rows;
    int cols;

    List<Entry> entry;
    SerialBlock(int r, int c, List<Entry> entry){
        this.rows = r;
        this.cols = c;
        this.entry = entry;

    }
}

/*
    As LinkedSparseMatrix is not Serializable we have implemented this class to make a wrapper for Serialization
    the SparseMatrix . This will help in map and reduce operation in spark
 */

class SMContainer implements Serializable{
    transient  LinkedSparseMatrix mat;

    SMContainer(LinkedSparseMatrix mat){
        this.mat = mat;
    }
    SMContainer(){
        mat = null;
    }


    /* Wrting Object as Serializable*/

    private void writeObject(ObjectOutputStream oos) throws Exception {
        Iterator<MatrixEntry> it = mat.iterator();
        List<Entry> entries = new ArrayList<>();
        while(it.hasNext()){
            MatrixEntry entry = it.next();
            entries.add(new Entry(entry.row(), entry.column(), entry.get()));
        }
        SerialBlock sb = new SerialBlock(mat.numRows(), mat.numColumns(), entries);
        oos.writeObject(sb);

    }

    /*Reading the Serializable Object*/
    private void readObject(ObjectInputStream ois) throws Exception {

        SerialBlock sb   = (SerialBlock) ois.readObject();
        mat = new LinkedSparseMatrix(sb.rows, sb.cols);
        for (Entry entry: sb.entry){
            mat.set(entry.r, entry.c, entry.d);
        }
    }
}

public class Prune {
    public static boolean NORMALIZE = true;
    public static double NORM_CONSTANT = 0.0;
    public Duration in_getBounds = Duration.ZERO;
    public Duration in_getIntervalWeight = Duration.ZERO;
    public Duration in_getNodesInTime = Duration.ZERO;
    public static Duration solveTime = Duration.ZERO;
    public Duration aggTime = Duration.ZERO;
    public Duration normLTime = Duration.ZERO;
    public static Duration volTime = Duration.ZERO;
    public long callsTo_getIntervalWeight = 0L;
    public HashMap<Pair<Integer, Integer>, double[]> preComputedVolumes = new HashMap();
    public HashMap<Pair<Integer, Integer>, Double> halfLambdas = new HashMap();
    public HashMap<Pair<Integer, Integer>, LinkedSparseMatrix> aggregations = new HashMap();

    JavaPairRDD<Pair<Integer, Integer>, SMContainer>  fullRDD ;
    private TreeMap<Integer, HashMap<Edge, Double>> timeGraph;
    private TreeMap<Integer, HashMap<Integer, Double>> nodeGraph;
    public int maxNode;
    public int totalTime;
    public int startTime;
    public int endTime;
    private static final int MIN_INTERSECTIONS = 1;
    private IntToDoubleFunction normalizingFunciton;
    private double bestN2factor;
    private Set<Integer> bestNodes;
    private int bestStartTime;
    private int bestEndTime;

    public static double normalizeConductance(double phi, int num_timestamps) {
        if (!NORMALIZE) {
            return phi;
        }
        return phi / Math.pow(num_timestamps, NORM_CONSTANT);
    }

    public static double unnormalizeConductance(double phi, int num_timestamps) {
        if (!NORMALIZE) {
            return phi;
        }
        return phi * Math.pow(num_timestamps, NORM_CONSTANT);
    }

    public Prune(String filename, Path basepath, boolean isOld, boolean oneBasedTime) {
        if (isOld) {
            this.readOldGraph(filename, basepath);
        } else {
            this.readGraph(filename, basepath, oneBasedTime);
        }
    }

    private void readOldGraph(String filename, Path basepath) {
        this.maxNode = Integer.MIN_VALUE;
        this.timeGraph = new TreeMap();
        HashSet<Integer> allNodes = new HashSet<Integer>();
        try {
            Scanner timeGraphScanner = new Scanner(new File(basepath + "/graph/" + filename));
            timeGraphScanner.nextLine();
            while (timeGraphScanner.hasNextLine()) {
                HashMap<Edge, Double> edgeMap;
                String line = timeGraphScanner.nextLine();
                String[] s = line.split(",");
                if (s.length != 3) {
                    System.out.println("Input file in not in expected format");
                    timeGraphScanner.close();
                    throw new NoSuchElementException();
                }
                Integer node1 = parseInt(s[0]);
                Integer node2 = parseInt(s[1]);
                this.maxNode = node1 > this.maxNode ? node1 : this.maxNode;
                this.maxNode = node2 > this.maxNode ? node2 : this.maxNode;
                allNodes.add(node1);
                allNodes.add(node2);
                Double t = Double.parseDouble(s[2]);
                int floorInt = new Double(Math.floor(t)).intValue();
                Edge nodePair = new Edge(node1, node2);
                if (this.timeGraph.containsKey(floorInt)) {
                    edgeMap = this.timeGraph.get(floorInt);
                    edgeMap.compute(nodePair, (k, v) -> v == null ? 1.0 : v + 1.0);
                    continue;
                }
                edgeMap = new HashMap<Edge, Double>();
                edgeMap.put(nodePair, 1.0);
                this.timeGraph.put(floorInt, edgeMap);
            }
            this.startTime = this.timeGraph.firstKey();
            this.endTime = this.timeGraph.lastKey();
            this.totalTime = this.endTime - this.startTime;
            System.out.println("For file: " + filename);
            System.out.println("Max Nodes: " + this.maxNode);
            System.out.println("Total Time Length: " + this.totalTime);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void readGraph(String filename, Path basepath, boolean oneBasedTime) {
        this.maxNode = Integer.MIN_VALUE;
        TreeSet<Integer> allNodes = new TreeSet<>();
        this.timeGraph = new TreeMap<>();
        try {
            Path filepath = basepath.resolve(filename);
            Scanner timeGraphScanner = new Scanner(filepath.toFile());
            timeGraphScanner.nextLine();
            while (timeGraphScanner.hasNextLine()) {
                Double weight;
                Integer time;
                Integer node1;
                Integer node2;
                String line = timeGraphScanner.nextLine();
                String[] s = line.split(",");
                if (s.length != 4) {
                    System.out.println("Input file in not in expected format");
                    System.out.println("Columns found: " + s.length + " in line: " + line);
                    continue;
                }
                try {
                    node1 = parseInt(s[0]);
                    node2 = parseInt(s[1]);
                    time = parseInt(s[2]);
                    if (oneBasedTime) {
                        time = time - 1;
                    }
                    weight = Double.parseDouble(s[3]);
                }
                catch (NumberFormatException e) {
                    System.out.println(line);
                    continue;
                }
                allNodes.add(node1);
                allNodes.add(node2);
                this.maxNode = node1 > this.maxNode ? node1 : this.maxNode;
                this.maxNode = node2 > this.maxNode ? node2 : this.maxNode;
                Edge edge = new Edge(node1, node2);
                if (this.timeGraph.containsKey(time)) {
                    this.timeGraph.get(time).put(edge, weight);
                    continue;
                }
                HashMap<Edge, Double> edgeMap = new HashMap<Edge, Double>();
                edgeMap.put(edge, weight);
                this.timeGraph.put(time, edgeMap);
            }
            if (allNodes.first() != 0 || allNodes.last() != allNodes.size() - 1) {
                System.err.println("Nodes not consecutively numbered!");
                System.err.println("\tFirst = " + allNodes.first() + "; last = " + allNodes.last() + "; size = " + allNodes.size());
                System.exit(-2);
            }
            this.startTime = this.timeGraph.firstKey();
            this.endTime = this.timeGraph.lastKey();
            this.totalTime = this.endTime - this.startTime;
            System.out.println("Total Nodes: " + allNodes.size());
            System.out.println(this.startTime + " " + this.endTime + " Total Time Length: " + this.totalTime);
            timeGraphScanner.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void getNodeWeights() {
        this.nodeGraph = new TreeMap<>();
        for (int time : this.timeGraph.keySet()) {
            if (!this.nodeGraph.containsKey(time)) {
                this.nodeGraph.put(time, new HashMap<>());
            }
            for (Map.Entry<Edge, Double> entry : this.timeGraph.get(time).entrySet()) {
                this.nodeGraph.get(time).compute(entry.getKey().getNode1(), (k, v) -> v == null ? entry.getValue() : v + entry.getValue());
                this.nodeGraph.get(time).compute(entry.getKey().getNode2(), (k, v) -> v == null ? entry.getValue() : v + entry.getValue());
            }
        }
    }

    public double getIntervalWeight(int subStart, int subEnd, int wholeStart, int wholeEnd) {
        ++this.callsTo_getIntervalWeight;
        Instant sTime = Instant.now();
        double weight = Double.MAX_VALUE;
        ArrayList<Pair<Integer, Integer>> spans = this.getSpans(subStart, subEnd);
        ArrayList<Pair<Integer, Integer>> wholeSpans = this.getSpans(wholeStart, wholeEnd);
        for (int node = 0; node <= this.maxNode; ++node) {
            double top = this.getCachedDegree(subStart, subEnd, node, spans);
            if (top == 0.0) continue;
            double bottom = this.getCachedDegree(wholeStart, wholeEnd, node, wholeSpans);
            double ratio = top / bottom;
            weight = ratio < weight ? ratio : weight;
        }
        this.in_getIntervalWeight = this.in_getIntervalWeight.plus(Duration.between(sTime, Instant.now()));
        return weight;
    }

    public static ArrayList<Pair<Integer, Integer>> getSpans(int start, int end) {
        ArrayList<Pair<Integer, Integer>> result = new ArrayList<Pair<Integer, Integer>>();
        while (start <= end) {
            int adv = Integer.lowestOneBit(start);
            if (adv == 0) {
                adv = Integer.highestOneBit(end + 1);
            }
            while (start + adv > end + 1) {
                adv /= 2;
            }
            Pair<Integer, Integer> p = new Pair<Integer, Integer>(start, start + adv - 1);
            result.add(p);
            start += adv;
        }
        return result;
    }

    private double getCachedDegree(int start, int end, int node, List<Pair<Integer, Integer>> spans) {
        double[] vols;
        Pair<Integer, Integer> span = new Pair<Integer, Integer>(start, end);
        if (this.preComputedVolumes.containsKey(span)) {
            vols = this.preComputedVolumes.get(span);
            if (vols[node] > 0.0) {
                return vols[node];
            }
        } else {
            vols = new double[this.maxNode + 1];
        }
        double result = 0.0;
        for (Pair<Integer, Integer> p : spans) {
            if (!this.preComputedVolumes.containsKey(p)) continue;
            double[] v = this.preComputedVolumes.get(p);
            result += v[node];
        }
        vols[node] = result;
        return result;
    }

    public double[] computeVolumes(int start, int end) {
        Instant sTime = Instant.now();
        LinkedSparseMatrix lsm = this.getAggregation(start, end);
        double[] vols = new double[this.maxNode + 1];
        for (int i = 0; i <= this.maxNode; ++i) {
            vols[i] = lsm.get(i, i);
        }
        Duration curVolTime = Duration.between(sTime, Instant.now());
        volTime = volTime.plus(curVolTime);
        return vols;
    }

    public void preaggregate() {

        List<Integer> timeList =  new ArrayList<>();
        for (int i = this.startTime; i <= this.endTime; ++i) {
            timeList.add(i);
        }
        TreeMap<Integer, HashMap<Edge, Double>> timeGraphtmp = timeGraph;
        int len = this.maxNode + 1;

        /*
            This will give the Java SparkContext
         */
        JavaSparkContext jsc = DynCommDriver.getJsc();

        /*
            Getting all the time and parallelising it so that we can compute in parllel

         */
        JavaRDD<Integer> rdd = jsc.parallelize(timeList);

        /*
            We are computing all the LinkedSparse Matrix in parallel so that we can use
            for reduction and computation of aggreagared weights
         */
        JavaPairRDD<Pair<Integer, Integer>, SMContainer>  pairRDD = rdd.map(i -> {
            LinkedSparseMatrix lsm = new LinkedSparseMatrix(len, len);
            for (Edge e : timeGraphtmp.get(i).keySet()) {
                int n1 = e.getNode1();
                int n2 = e.getNode2();
                double weight = timeGraphtmp.get(i).get(e);
                lsm.set(n1, n2, lsm.get(n1, n2) - weight);
                lsm.set(n2, n1, lsm.get(n2, n1) - weight);
                lsm.set(n1, n1, lsm.get(n1, n1) + weight);
                lsm.set(n2, n2, lsm.get(n2, n2) + weight);
            }
            Pair<Integer, Integer> span = new Pair<Integer, Integer>(i, i);
            return new Tuple2<>(span, new SMContainer(lsm));
        }).mapToPair(x -> x );

        JavaPairRDD<Pair<Integer, Integer>, SMContainer>  fullRDD = pairRDD;
        for (int size = 2; size < this.totalTime; size *= 2) {
            int i = this.startTime;


            List<Tuple2<Pair<Integer, Integer> , Pair<Integer,Integer>>> allTimeList =  new ArrayList<>();
            while (i + (size - 1) <= this.endTime) {
                Pair<Integer, Integer> wholeSpan = new Pair<Integer, Integer>(i, i + (size - 1));
                Pair<Integer, Integer> firstSpan = new Pair<Integer, Integer>(i, i + (size / 2 - 1));
                Pair<Integer, Integer> secondSpan = new Pair<Integer, Integer>(i + size / 2, i + (size - 1));
                allTimeList.add(new Tuple2<>(firstSpan, wholeSpan));
                System.out.println(wholeSpan);
                i = i+size;
            }

            /*
                Here We are computing all the aggreaged weights for each time bounds
                Like 0-1, 1-2
                     0-3, 4-7
                     .......
                This computation is parallel
             */
            JavaPairRDD<Pair<Integer, Integer>, Pair<Integer, Integer>> tmprdd = jsc.parallelize(allTimeList).mapToPair(x -> x);
            JavaPairRDD<Pair<Integer, Integer>, SMContainer> oldrdd = pairRDD;
            pairRDD = oldrdd.join(tmprdd).mapToPair(x-> new Tuple2<>(x._2._2, x._2._1)).reduceByKey((x,y) ->{
                LinkedSparseMatrix wholeM = (LinkedSparseMatrix)x.mat.copy();
                wholeM.add(y.mat);
                return new SMContainer(wholeM);

            });
            fullRDD = fullRDD.union(pairRDD);
        }
        this.fullRDD = fullRDD;
        //fullRDD.collectAsMap().forEach((x,y) ->this.aggregations.put(x,y.mat));

    }

    private LinkedSparseMatrix getAggregation(int start, int end) {
        LinkedSparseMatrix result = new LinkedSparseMatrix(this.maxNode + 1, this.maxNode + 1);
        ArrayList<Pair<Integer, Integer>> intervals = this.getSpans(start, end);
        for (Pair<Integer, Integer> iv : intervals) {
            if (!this.aggregations.containsKey(iv)) {
                System.err.println("Missing aggregation: " + iv);
            }
            LinkedSparseMatrix curM = this.aggregations.get(iv);
            result.add(curM);
        }
        return result;
    }

    public double getBounds(int start, int end) {
        Instant sTime = Instant.now();
        Pair<Integer, Integer> span = new Pair<Integer, Integer>(start, end);
        if (this.halfLambdas.containsKey(span)) {
            double lowerBounds = this.halfLambdas.get(span);
            this.in_getBounds = this.in_getBounds.plus(Duration.between(sTime, Instant.now()));
            return lowerBounds;
        }
        LinkedSparseMatrix lsm = this.getAggregation(start, end);
        if (!this.preComputedVolumes.containsKey(span)) {
            Instant volStart = Instant.now();
            double[] vols = new double[this.maxNode + 1];
            for (int i = 0; i <= this.maxNode; ++i) {
                vols[i] = lsm.get(i, i);
            }
            this.preComputedVolumes.put(span, vols);
            Duration curVolTime = Duration.between(volStart, Instant.now());
            volTime = volTime.plus(curVolTime);
        }
        this.aggTime = this.aggTime.plus(Duration.between(sTime, Instant.now()));
        Instant Lstart = Instant.now();
        LinkedSparseMatrix normalizedLaplacian = new LinkedSparseMatrix(this.maxNode + 1, this.maxNode + 1);
        for (MatrixEntry me : lsm) {
            int c = me.column();
            int r = me.row();
            double val = me.get();
            if (lsm.get(c, c) == 0.0 && lsm.get(r, r) == 0.0) {
                normalizedLaplacian.set(r, c, 0.0);
                continue;
            }
            double normalizedVal = val / (Math.sqrt(lsm.get(c, c)) * Math.sqrt(lsm.get(r, r)));
            normalizedLaplacian.set(r, c, normalizedVal);
        }
        this.normLTime = this.normLTime.plus(Duration.between(Lstart, Instant.now()));
        Instant solveStart = Instant.now();
        ArpackSym solver = new ArpackSym(normalizedLaplacian);
        Map resultsSA = solver.solve((int)Math.log(this.maxNode), ArpackSym.Ritz.SM);
        solveTime = solveTime.plus(Duration.between(solveStart, Instant.now()));
        double lambda2 = (Double)resultsSA.keySet().toArray()[resultsSA.keySet().size() - 2];
        double lowerBounds = lambda2 / 2.0;
        this.halfLambdas.put(span, new Double(lowerBounds));
        this.in_getBounds = this.in_getBounds.plus(Duration.between(sTime, Instant.now()));
        return lowerBounds;
    }



    /*
        Main function Where Eigen value computaion is going on
        We already have aggregated Weight for most of interval.
        We will use it to find second eigen vectors for them
     */
    public Map<Pair<Integer, Integer>, Double> getAllBounds(List<Pair<Integer, Integer>> alist) {
        JavaSparkContext jsc  = DynCommDriver.getJsc();
        JavaRDD<Pair<Integer, Integer>> crdd =  jsc.parallelize(alist);


        /*
            Just Getting all the main bound and bound which will calculate them
             First is bound which will calculate them
             Second is result bound
         */
        JavaPairRDD<Pair<Integer, Integer>, Pair<Integer, Integer>> maprdd = crdd.flatMap(x -> Prune.getSpans(x.getA(), x.getB()).stream().map(y -> new Tuple2<>(y, x)).collect(Collectors.toList()).iterator()).mapToPair(x -> x);


        /*
           Joining from main Rdd of SParse Matrix and finally getting the bound and matrix pair

        */
        JavaPairRDD<Pair<Integer, Integer>, SMContainer> rdd = maprdd.join(fullRDD).mapToPair(x -> new Tuple2<>(x._2._1, x._2._2)).reduceByKey((x, y) -> {

            LinkedSparseMatrix wholeM = (LinkedSparseMatrix) x.mat.copy();
            wholeM.add(y.mat);
            return new SMContainer(wholeM);
        });

        int len = this.maxNode + 1;
        Integer sync = 0;

        /*
            Here the computation of Eigen Value is going on
            Not Changing much of code Here


         */
        Map<Pair<Integer, Integer>, Pair<Double, double[]>> map1 = rdd.mapToPair(x -> {
            LinkedSparseMatrix lsm = x._2.mat;
            LinkedSparseMatrix normalizedLaplacian = new LinkedSparseMatrix(len, len);


            double[] vols = new double[len];
            for (int i = 0; i < len; ++i) {
                vols[i] = lsm.get(i, i);
            }

            for (MatrixEntry me : lsm) {
                int c = me.column();
                int r = me.row();
                double val = me.get();
                if (lsm.get(c, c) == 0.0 && lsm.get(r, r) == 0.0) {
                    normalizedLaplacian.set(r, c, 0.0);
                    continue;
                }
                double normalizedVal = val / (Math.sqrt(lsm.get(c, c)) * Math.sqrt(lsm.get(r, r)));
                normalizedLaplacian.set(r, c, normalizedVal);
            }
            double lowerBounds = 0.0;
            ArpackSym solver = new ArpackSym(normalizedLaplacian);
            Map resultsSA = solver.solve((int) Math.log(len - 1), ArpackSym.Ritz.SM);
            double lambda2 = (Double) resultsSA.keySet().toArray()[resultsSA.keySet().size() - 2];
            lowerBounds = lambda2 / 2.0;
            //this.halfLambdas.put(span, new Double(lowerBounds));
            return new Tuple2<>(x._1, new Pair<>(lowerBounds, vols));
        }).collectAsMap();
        map1.forEach((x,y)->{
            halfLambdas.put(x, y.getA());
            preComputedVolumes.put(x, y.getB());
        } );

        /*
            Collected Lambdas are returned
        */
        return  halfLambdas;
    }
}

