package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class Edge
extends Pair<Integer, Integer> {
    private int node1 = this.getA();
    private int node2 = this.getB();

    public Edge(int node1, int node2) {
        super(node1, node2);
    }

    public int getNode1() {
        return this.node1;
    }

    public int getNode2() {
        return this.node2;
    }

    public boolean containsNode(int node) {
        return node == this.node1 || node == this.node2;
    }

    public Set<Edge> getAnyConnected(Set<Edge> searchSet) {
        return searchSet.parallelStream().filter(edge -> edge.containsAny(this)).collect(Collectors.toSet());
    }

    public boolean listHasEdge(Set<Integer> searchSet) {
        return searchSet.contains(this.node1) && searchSet.contains(this.node2);
    }

    public boolean listHasPartialEdge(Set<Integer> searchSet) {
        if (this.listHasEdge(searchSet)) {
            return false;
        }
        return searchSet.contains(this.node1) || searchSet.contains(this.node2);
    }

    public boolean containsAny(Edge searchEdge) {
        return searchEdge.containsNode(this.node1) || searchEdge.containsNode(this.node2);
    }

    public int getOtherNode(int node) {
        if (node == this.node1) {
            return this.node2;
        }
        if (node == this.node2) {
            return this.node1;
        }
        return 0;
    }

    public Set<Integer> toSet() {
        HashSet<Integer> result = new HashSet<Integer>(2);
        result.add(this.node1);
        result.add(this.node2);
        return result;
    }

    @Override
    public String toString() {
        return this.node1 + "," + this.node2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        Edge edgePair = (Edge)o;
        if (this.node1 == edgePair.node1 && this.node2 == edgePair.node2) {
            return true;
        }
        return this.node2 == edgePair.node1 && this.node1 == edgePair.node2;
    }

    @Override
    public int hashCode() {
        int result = this.node1 * this.node2;
        return result += 31 * (this.node1 + this.node2);
    }
}

