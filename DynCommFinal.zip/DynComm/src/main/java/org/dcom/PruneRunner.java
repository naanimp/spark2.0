package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Int;

import java.io.PrintWriter;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.function.IntToDoubleFunction;

public class PruneRunner {
    public Duration in_getCompositeBounds = Duration.ZERO;
    public Duration in_getPrecomputedBounds = Duration.ZERO;
    public Duration in_getMixedBounds = Duration.ZERO;
    public Duration in_calcVolumes = Duration.ZERO;
    public Duration in_precompute = Duration.ZERO;
    public Duration in_extraVolumes = Duration.ZERO;
    public Duration in_easyGroups = Duration.ZERO;
    public Duration in_harderGroups = Duration.ZERO;
    int[] PREC_SIZES = new int[]{1, 2, 4, 5, 8, 9, 14, 15, 20, 21, 27, 28, 35, 36, 44, 45, 54, 55, 65, 66, 77, 78, 90, 91, 103, 104, 120, 137, 155, 174, 194, 215, 237, 260, 284};

    public void precompute(Prune p, double[][] bounds, boolean printEigs) {

        Instant sTime = Instant.now();
        p.preaggregate();
        List<Pair<Integer, Integer>> alist = new ArrayList<>();
        alist.add(new Pair<>(p.startTime, p.endTime));

        for (int t = p.startTime; t <= p.endTime; ++t) {
            alist.add(new Pair(t,t));
        }

        for (int size : this.PREC_SIZES) {
            if (size == 1) continue;
            int t = p.startTime;
            while (t + size - 1 <= p.endTime) {
                int end = t + size - 1;
                alist.add(new Pair<>(t,end));
                t += size;
            }
        }
       Map<Pair<Integer, Integer>, Double> boundsMap = p.getAllBounds(alist);
        boundsMap.forEach((x,y)-> {
            bounds[x.getA()][x.getB()] = Prune.normalizeConductance(y, x.getB()-x.getA()+1);
        });
    }

    private void calcNewVolumes(Prune p) {
        int t;
        Pair<Integer, Integer> span;
        Instant sTime = Instant.now();
        double[] endVols = null;
        for (t = p.startTime; t <= p.endTime; ++t) {
            span = new Pair<Integer, Integer>(t, t);
            if (p.preComputedVolumes.get(span) == null ) {
                double[] vols = p.computeVolumes(t, t);

                p.preComputedVolumes.put(span, vols);
            }
            if (t == p.endTime) {
                double[] vols = p.preComputedVolumes.get(span);

                endVols = Arrays.copyOf(vols, vols.length);
            }
        }
        for (int i = 0; i < this.PREC_SIZES.length; ++i) {
            int full_size = this.PREC_SIZES[i];
            if (full_size == 1) continue;
            int half_size = this.PREC_SIZES[i - 1];
            int t2 = p.startTime;
            while (t2 + full_size - 1 <= p.endTime) {
                double[] v2;
                int end = t2 + full_size - 1;
                Pair<Integer, Integer> span2 = new Pair<Integer, Integer>(t2, end);
                Pair<Integer, Integer> s1 = new Pair<Integer, Integer>(t2, t2 + half_size - 1);
                Pair<Integer, Integer> s2 = new Pair<Integer, Integer>(t2 + half_size, end);
                double[] v1 = p.preComputedVolumes.get(s1);
                if (p.preComputedVolumes.containsKey(s2)) {
                    v2 = p.preComputedVolumes.get(s2);
                } else {
                    int thisSize;
                    v2 = new double[v1.length];
                    for (int st = t2 + half_size; st <= end; st += thisSize) {
                        double[] v3 = new double[v1.length];
                        thisSize = 1;
                        for (int k = i - 1; k >= 0; --k) {
                            thisSize = this.PREC_SIZES[k];
                            Pair<Integer, Integer> s3 = new Pair<Integer, Integer>(st, st + thisSize - 1);
                            if (!p.preComputedVolumes.containsKey(s3)) continue;
                            v3 = p.preComputedVolumes.get(s3);
                            break;
                        }
                        for (int m = 0; m < v1.length; ++m) {
                            double[] arrd = v2;
                            int n = m;
                            arrd[n] = arrd[n] + v3[m];
                        }
                    }
                    p.preComputedVolumes.put(s2, v2);
                }
                double[] sum = new double[v1.length];
                for (int j = 0; j < v1.length; ++j) {
                    sum[j] = v1[j] + v2[j];
                }
                p.preComputedVolumes.put(span2, sum);
                ++t2;
            }
        }
        for (t = p.endTime - 1; t >= p.startTime; --t) {
            span = new Pair<Integer, Integer>(t, p.endTime);
            Pair<Integer, Integer> now = new Pair<Integer, Integer>(t, t);
            double[] v1 = p.preComputedVolumes.get(now);
            double[] sum = new double[v1.length];
            for (int i = 0; i < v1.length; ++i) {
                sum[i] = v1[i] + endVols[i];
            }
            p.preComputedVolumes.put(span, sum);
            endVols = sum;
        }
        this.in_calcVolumes = this.in_calcVolumes.plus(Duration.between(sTime, Instant.now()));
    }

    public Prune loadFile(String filename, Path basepath, boolean isOld, boolean oneBasedTime) {
        return new Prune(filename, basepath, isOld, oneBasedTime);
    }

    public double[][] getAllBounds(Prune p, double estimate, double[][] result) {
        int totalTime = p.totalTime;
        double boundCount = 0.0;
        double pruneCount = 0.0;
        for (int range = 0; range < totalTime; ++range) {
            int n = p.startTime;
            while (n + range <= p.endTime) {
                boundCount += 1.0;
                if (result[n][range] > 0.0){
                    if (estimate < result[n][range]) {
                        pruneCount += 1.0;
                    }
                } else {
                    int end = n + range;
                    double bounds = p.getBounds(n, end);
                    result[n][range] = Prune.normalizeConductance(bounds, range + 1);
                    if (estimate < result[n][range]) {
                        pruneCount += 1.0;
                    }
                }
                ++n;
            }
        }
        return result;
    }

    public List<Integer> findNewIntervals(int start, int end, int maxSize) {
        ArrayList<Integer> intervals = new ArrayList<Integer>();
        TreeSet<TreeSet<Integer>> result = this.findNewIntervalsHelp(start, end, maxSize);
        for (TreeSet<Integer> pair : result) {
            int a = pair.first();
            int b = pair.last();
            intervals.add(b - a + 1);
        }
        return intervals;
    }

    public TreeSet<TreeSet<Integer>> findNewIntervalsHelp(int start, int end, int maxSize) {
        int i;
        TreeSet<TreeSet<Integer>> ranges = new TreeSet<TreeSet<Integer>>(new TreeSetComparator());
        int cover_start = -1;
        int cover_end = -1;
        for (i = this.PREC_SIZES.length - 1; i >= 0; --i) {
            int size = this.PREC_SIZES[i];
            if (size > maxSize) continue;
            for (int t = start; t <= end; ++t) {
                if (t % size != 0) continue;
                int st = t;
                for (int et = t + (size - 1); et <= end; et += size) {
                    if (cover_start == -1) {
                        cover_start = t;
                    }
                    cover_end = et;
                    TreeSet<Integer> pair = new TreeSet<Integer>();
                    pair.add(st);
                    pair.add(et);
                    ranges.add(pair);
                    st += size;
                }
                if (cover_start != -1) break;
            }
            if (cover_start != -1) break;
        }
        if (cover_start != -1 && i > 0 && cover_start > start) {
            ranges.addAll(this.findNewIntervalsHelp(start, cover_start - 1, this.PREC_SIZES[i - 1]));
        }
        if (cover_end != -1 && i > 0 && cover_end < end) {
            ranges.addAll(this.findNewIntervalsHelp(cover_end + 1, end, this.PREC_SIZES[i - 1]));
        }
        return ranges;
    }

    public double getPrecomputedBounds(Prune prune, int start, int end, double[][] bounds) {
        Instant sTime = Instant.now();
        if (bounds[start][end - start] > 0.0) {
            this.in_getPrecomputedBounds = this.in_getPrecomputedBounds.plus(Duration.between(sTime, Instant.now()));
            return bounds[start][end - start];
        }
        double b = prune.getBounds(start, end);
        bounds[start][end - start] = Prune.normalizeConductance(b, end - start + 1);
        this.in_getPrecomputedBounds = this.in_getPrecomputedBounds.plus(Duration.between(sTime, Instant.now()));
        return b;
    }

    /*
     * WARNING - void declaration
     */
    public double[][] getNewMixedBounds(Prune p, double estimate, double[][] bounds, boolean group) {
        int totalTime;
        Instant sTime = Instant.now();
        int maxSize = totalTime = p.totalTime;
        p.getNodeWeights();
        System.out.print("Calculating volumes... ");
        this.calcNewVolumes(p);
        System.out.println("DONE!");
        for (int t = p.startTime; t <= p.endTime; ++t) {
            for (int i = 0; i < this.PREC_SIZES.length; ++i) {
                int full_size = this.PREC_SIZES[i];
                if (full_size == 1 || t + (full_size - 1) > p.endTime || bounds[t][full_size - 1] > 0.0) continue;
                int myEnd = t + full_size - 1;
                List<Integer> myIntervals = this.findNewIntervals(t, myEnd, maxSize);
                double compositeBound = 0.0;
                int temp = 0;
                for (int interval : myIntervals) {
                    int subStart = t + temp;
                    int subEnd = subStart + (interval - 1);
                    double pb = this.getPrecomputedBounds(p, subStart, subEnd, bounds);
                    double iw = p.getIntervalWeight(subStart, subEnd, t, myEnd);
                    compositeBound += iw * pb;
                    temp += interval;
                }
                bounds[t][full_size - 1] = compositeBound = Prune.normalizeConductance(compositeBound, full_size);
            }
        }
        int groupCount = 0;
        int boundCount = 0;
        for (int t = p.startTime; t < p.endTime; ++t) {
            int subEnd;
            int subStart;
            int full_size;
            int half_size;
            int i;
            for (i = 1; i < this.PREC_SIZES.length; ++i) {
                full_size = this.PREC_SIZES[i];
                if (t + (full_size - 1) > p.endTime) break;
                half_size = this.PREC_SIZES[i - 1];
                if (half_size == 1) continue;
                double answer = 0.0;
                Pair<Integer, Integer> sp22 = null;
                int end = t + full_size - 1;
                int mid = t + half_size - 1;
                if (group && full_size - half_size >= 4) {
                    sp22 = new Pair<Integer, Integer>(t, end);
                    double[] fv = null;
                    if (p.preComputedVolumes.containsKey(sp22)) {
                        fv = p.preComputedVolumes.get(sp22);
                    } else {
                        System.out.println("ERROR! Missing precomputed volume in getMixedBounds!");
                        System.out.println("\tsp2 = " + sp22);
                        System.exit(-3);
                    }
                    ArrayList<Pair<Integer, Integer>> intervals = new ArrayList<Pair<Integer, Integer>>();
                    List<Integer> intervalSizes = this.findNewIntervals(t, mid, maxSize);
                    int tmp = 0;
                    for (int s : intervalSizes) {
                        subStart = t + tmp;
                        subEnd = subStart + (s - 1);
                        Pair<Integer, Integer> p1 = new Pair<Integer, Integer>(subStart, subEnd);
                        intervals.add(p1);
                        tmp += s;
                    }
                    for (Pair sp : intervals) {
                        double [] iv2 = null;
                        if (p.preComputedVolumes.containsKey(sp)) {
                            iv2 = p.preComputedVolumes.get(sp);
                        } else {
                            System.out.println("ERROR! Missing inner precomputed volume in getMixedBounds!");
                            System.out.println("\tsp = " + sp);
                            System.exit(-3);
                        }
                        double lamb = 0.0;
                        if (p.halfLambdas.containsKey(sp)) {
                            lamb = p.halfLambdas.get(sp);
                        } else {
                            System.out.println("ERROR! Missing precomputed lambda in getMixedBounds!");
                            System.out.println("\tsp = " + sp);
                            System.exit(-3);
                        }
                        double ratio = 1.0;
                        for (int v = 0; v <= p.maxNode; ++v) {
                            double  r = iv2[v] / fv[v];
                            if (!(r < ratio)) continue;
                            ratio = r;
                        }
                        answer += ratio * lamb;
                    }
                    answer = Prune.normalizeConductance(answer, full_size);
                }
                if (estimate < answer) {
                    for (int dur = half_size; dur < full_size - 1; ++dur) {
                        ++groupCount;
                        if (!(bounds[t][dur] < answer)) continue;
                        ++boundCount;
                        bounds[t][dur] = answer;
                    }
                    continue;
                }
                for (int range = half_size; range < full_size - 1; ++range) {
                    if (bounds[t][range] > 0.0) continue;
                    int myEnd = t + range;
                    List<Integer> myIntervals = this.findNewIntervals(t, myEnd, maxSize);
                    double compositeBound = 0.0;
                    int temp = 0;
                    for (int interval : myIntervals) {
                        int subStart2 = t + temp;
                        int subEnd2 = subStart2 + (interval - 1);
                        double pb = this.getPrecomputedBounds(p, subStart2, subEnd2, bounds);
                        double iw = p.getIntervalWeight(subStart2, subEnd2, t, myEnd);
                        compositeBound += iw * pb;
                        temp += interval;
                    }
                    bounds[t][range] = compositeBound = Prune.normalizeConductance(compositeBound, range + 1);
                }
            }
            half_size = this.PREC_SIZES[i - 1];
            int mid = t + half_size - 1;
            int end = p.endTime;
            full_size = end - t + 1;
            boolean final_group = false;
            if (group && end - mid > 3) {
                Pair<Integer, Integer> sp2 = new Pair<Integer, Integer>(t, end);
                double[] fv = null;
                if (p.preComputedVolumes.containsKey(sp2)) {
                    fv = p.preComputedVolumes.get(sp2);
                } else {
                    System.out.println("ERROR! Missing precomputed volume in getMixedBounds!");
                    System.out.println("\tsp2 = " + sp2);
                    System.exit(-3);
                }
                ArrayList<Pair<Integer, Integer>> intervals = new ArrayList<Pair<Integer, Integer>>();
                List<Integer> intervalSizes = this.findNewIntervals(t, mid, maxSize);
                int tmp = 0;
                for (int s : intervalSizes) {
                    int subStart3 = t + tmp;
                    int subEnd3 = subStart3 + (s - 1);
                    Pair<Integer, Integer> p1 = new Pair<Integer, Integer>(subStart3, subEnd3);
                    intervals.add(p1);
                    tmp += s;
                }
                double answer = 0.0;
                for (Pair sp : intervals) {
                    double[] iv = null;
                    if (p.preComputedVolumes.containsKey(sp)) {
                        iv = p.preComputedVolumes.get(sp);
                    } else {
                        System.out.println("ERROR! Missing inner precomputed volume in getMixedBounds!");
                        System.out.println("\tsp = " + sp);
                        System.exit(-3);
                    }
                    double lamb = 0.0;
                    if (p.halfLambdas.containsKey(sp)) {
                        lamb = p.halfLambdas.get(sp);
                    } else {
                        System.out.println("ERROR! Missing precomputed lambda in getMixedBounds!");
                        System.out.println("\tsp = " + sp);
                        System.exit(-3);
                    }
                    double ratio = 1.0;
                    for (int v = 0; v <= p.maxNode; ++v) {
                        double r = iv[v] / fv[v];
                        if (!(r < ratio)) continue;
                        ratio = r;
                    }
                    answer += ratio * lamb;
                }
                if (estimate < (answer = Prune.normalizeConductance(answer, full_size))) {
                    final_group = true;
                    int dur = half_size;
                    while (t + dur <= p.endTime) {
                        ++groupCount;
                        if (bounds[t][dur] < answer) {
                            ++boundCount;
                            bounds[t][dur] = answer;
                        }
                        ++dur;
                    }
                }
            }
            if (final_group) continue;
            int range = half_size;
            while (t + range <= p.endTime) {
                if (!(bounds[t][range] > 0.0)) {
                    int myEnd = t + range;
                    List<Integer> myIntervals = this.findNewIntervals(t, myEnd, maxSize);
                    double compositeBound = 0.0;
                    int temp = 0;
                    for (int interval : myIntervals) {
                        subStart = t + temp;
                        subEnd = subStart + (interval - 1);
                        double pb = this.getPrecomputedBounds(p, subStart, subEnd, bounds);
                        double iw = p.getIntervalWeight(subStart, subEnd, t, myEnd);
                        compositeBound += iw * pb;
                        temp += interval;
                    }
                    bounds[t][range] = compositeBound = Prune.normalizeConductance(compositeBound, range + 1);
                }
                ++range;
            }
        }
        System.out.println("Done with getMixedBounds, grouping pruned " + groupCount + " intervals, changed " + boundCount + " bounds.");
        this.in_getMixedBounds = this.in_getMixedBounds.plus(Duration.between(sTime, Instant.now()));
        return bounds;
    }
}

