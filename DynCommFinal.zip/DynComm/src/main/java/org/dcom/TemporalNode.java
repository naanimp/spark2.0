package org.dcom;/*
 * Decompiled with CFR 0.146.
 */
import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

public class TemporalNode
implements Comparable<TemporalNode>, Serializable    {
    private Integer time;
    private Integer node;

    TemporalNode(Integer t, Integer n) {
        this.time = new Integer(t);
        this.node = new Integer(n);
    }

    public Integer getNode() {
        return new Integer(this.node);
    }

    public Integer getTime() {
        return new Integer(this.time);
    }

    @Override
    public int compareTo(TemporalNode tn) {
        if (this.time.equals(tn.time)) {
            return this.node.compareTo(tn.node);
        }
        if (this.time < tn.time) {
            return -1;
        }
        return 1;
    }

    public String toString() {
        return "(" + this.node + "@" + this.time + ")";
    }

    public static Integer[] span(Set<TemporalNode> nodes) {
        Integer[] result = new Integer[]{Integer.MAX_VALUE, Integer.MIN_VALUE};
        for (TemporalNode tn : nodes) {
            Integer i = tn.getTime();
            if (i < result[0]) {
                result[0] = i;
            }
            if (i <= result[1]) continue;
            result[1] = i;
        }
        return result;
    }

    public static TreeSet<Integer> extractVertices(Set<TemporalNode> nodes) {
        TreeSet<Integer> result = new TreeSet<Integer>();
        for (TemporalNode tn : nodes) {
            result.add(tn.getNode());
        }
        return result;
    }

    public static TreeSet<Integer> extractTimes(Set<TemporalNode> nodes) {
        TreeSet<Integer> result = new TreeSet<Integer>();
        for (TemporalNode tn : nodes) {
            result.add(tn.getTime());
        }
        return result;
    }

}

