package org.dcom;/*
 * Decompiled with CFR 0.146.
 */
import java.io.Serializable;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTNComparator
implements Comparator<TreeSet<TemporalNode>> , Serializable
{
    @Override
    public int compare(TreeSet<TemporalNode> s1, TreeSet<TemporalNode> s2) {
        if (s1 == null) {
            if (s2 == null) {
                return 0;
            }
            return -1;
        }
        if (s2 == null) {
            return 1;
        }
        Iterator<TemporalNode> i1 = s1.iterator();
        Iterator<TemporalNode> i2 = s2.iterator();
        while (i1.hasNext() && i2.hasNext()) {
            TemporalNode x2;
            TemporalNode x1 = i1.next();
            if (x1.compareTo(x2 = i2.next()) == -1) {
                return -1;
            }
            if (x1.compareTo(x2) != 1) continue;
            return 1;
        }
        if (i1.hasNext()) {
            return 1;
        }
        if (i2.hasNext()) {
            return -1;
        }
        return 0;
    }
}

