package org.dcom;/*
 * Decompiled with CFR 0.146.
 */
import java.io.Serializable;
import java.util.Objects;

public class Pair<A, B> implements Serializable {
    private final A a;
    private final B b;

    public Pair(A a, B b) {
        this.a = a;
        this.b = b;
    }

    public A getA() {
        return this.a;
    }

    public B getB() {
        return this.b;
    }

    public int hashCode() {
        return Objects.hash(this.a, this.b);
    }

    public boolean equals(Object o) {
        if (o == null || !(o instanceof Pair)) {
            return false;
        }
        Pair that = (Pair)o;
        return Objects.equals(this.a, that.a) && Objects.equals(this.b, that.b);
    }

    public String toString() {
        return "(" + this.a.toString() + "," + this.b.toString() + ")";
    }
}

