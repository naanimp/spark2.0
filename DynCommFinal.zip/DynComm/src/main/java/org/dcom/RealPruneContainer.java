package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import org.apache.spark.api.java.JavaRDD;
import scala.Tuple2;

import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

public class RealPruneContainer
extends PruneContainer {
    public static boolean FAST_ESTIMATE = false;
    public static int HASH_ATTEMPTS = 100;
    public static int INTERVALS_TO_CHECK = 10;
    static boolean DISPLAY_TIMINGS = true;
    static Duration in_getFastEstimate = Duration.ZERO;
    double[][] bounds;
    double estimate;
    int T;
    boolean[] sizePruned;
    boolean[] sizeUpdated;
    boolean[] timePruned;
    boolean[] timeUpdated;

    static double getFastEstimate(TGraph g, int T, double[][] bounds) {
        Instant sTime = Instant.now();
        in_getFastEstimate = Duration.ZERO;
        TreeMap eigs = new TreeMap();
        double min = 1.0;
        int st = -1;
        int dur = -1;
        for (int i = 0; i < T; ++i) {
            int j = 0;
            while (i + j < T) {
                if (bounds[i][j] > 0.0) {
                    ArrayList<Integer> range = new ArrayList<Integer>();
                    range.add(i);
                    range.add(i + j);
                    eigs.put(bounds[i][j], range);
                    if (bounds[i][j] < min) {
                        min = bounds[i][j];
                        st = i;
                        dur = j;
                    }
                }
                ++j;
            }
        }
        double lamb = Prune.unnormalizeConductance(min, dur + 1);
        double upper = Prune.normalizeConductance(Math.sqrt(4.0 * lamb), dur + 1);
        int attempt_counter = 0;
        if (HASH_ATTEMPTS > 0) {
            double bestCond = 1.0;
            for (Object  e : eigs.keySet()) {
                if (attempt_counter >= INTERVALS_TO_CHECK) break;
                ArrayList<Integer> alist = (ArrayList<Integer>)eigs.get(e);
                st = (Integer)alist.get(0);
                dur = alist.get(1) - alist.get(0);
                int timebits = 2 * T / (dur + 1);
                TemporalWeightedMinhashGadget hasher = new TemporalWeightedMinhashGadget(g.vertexSet().last() + 1, 12, 4, timebits, dur + 1);
                TreeMap<Double, TreeSet<TemporalNode>> hashResult = hasher.performLimitedHash(g, st, st + dur);
                if (hashResult == null || hashResult.size() == 0) {
                    System.out.println("No hashing collisions in getFastEstimate.");
                } else {
                    Double hashScore = hashResult.lastKey();
                    int counter = 0;
                    TreeSet<TemporalNode> result = null;
                    while (hashScore != null && counter < HASH_ATTEMPTS) {
                        TreeSet<TemporalNode> tempresult;
                        double[] conductance;
                        TreeMap tempMap;
                        TreeSet<TemporalNode> seeds = hashResult.get(hashScore);
                        if (seeds == null || seeds.size() == 0 || (tempresult = g.AndersenSwipes(tempMap = g.temporalRWRBeta(seeds, 0.15, 0.2, false, true, true), conductance = new double[1], true)) == null || tempresult.size() == 0) continue;
                        if (conductance[0] < bestCond) {
                            bestCond = conductance[0];
                            result = tempresult;
                        }
                        hashScore = hashResult.lowerKey(hashScore);
                        ++counter;
                    }
                    if (bestCond < upper) {
                        upper = bestCond;
                    }
                }
                ++attempt_counter;
            }
        }
        in_getFastEstimate = in_getFastEstimate.plus(Duration.between(sTime, Instant.now()));
        if (DISPLAY_TIMINGS) {
            System.out.println("Estimate time: " + in_getFastEstimate.toMillis() + " milliseconds");
        }
        return upper;
    }

    RealPruneContainer(TGraph g, int T, Path path, String filename, boolean oneBasedTime, double est, boolean DETAILED_TIMING, boolean useGroups, boolean useFull) {
        double e;
        DISPLAY_TIMINGS = DETAILED_TIMING;
        System.out.println("T = " + T);
        this.T = T;
        this.estimate = est;
        this.bounds = new double[T][T];
        Instant prune_start = Instant.now();
        PruneRunner pr = new PruneRunner();
        if (DISPLAY_TIMINGS) {
            System.out.println("\t@@@@@@ Load prune runner: " + Duration.between(prune_start, Instant.now()).getSeconds());
        }
        Prune p = pr.loadFile(filename, path, false, oneBasedTime);
        if (DISPLAY_TIMINGS) {
            System.out.println("\t@@@@@@ Done loading: " + Duration.between(prune_start, Instant.now()).getSeconds());
        }
        pr.precompute(p, this.bounds, true);
        if (FAST_ESTIMATE && (e = RealPruneContainer.getFastEstimate(g, T, this.bounds)) < this.estimate) {
            this.estimate = e;
        }
        this.bounds = useGroups ? pr.getNewMixedBounds(p, this.estimate, this.bounds, useGroups) : (useFull ? pr.getAllBounds(p, this.estimate, this.bounds) : pr.getNewMixedBounds(p, this.estimate, this.bounds, useGroups));
        if (DISPLAY_TIMINGS) {
            System.out.println("\t=-=-=-=-= Begin timing breakdown =-=-=-=-=");
            System.out.println("\t\tRealPruneContainer, getFastEstimate: " + in_getFastEstimate.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, getMixedBounds: " + pr.in_getMixedBounds.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, getCompositeBounds: " + pr.in_getCompositeBounds.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, getPrecomputedBounds: " + pr.in_getPrecomputedBounds.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, calcVolumes: " + pr.in_calcVolumes.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, precompute: " + pr.in_precompute.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, easyGroups: " + pr.in_easyGroups.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, extraVolumes: " + pr.in_extraVolumes.toMillis() + " milliseconds");
            System.out.println("\t\tPruneRunner, harderGroups: " + pr.in_harderGroups.toMillis() + " milliseconds");
            System.out.println("\t\tPrune, getIntervalWeight: " + p.in_getIntervalWeight.toMillis() + " milliseconds");
            System.out.println("\t\t\t ... in " + p.callsTo_getIntervalWeight + " calls.");
            System.out.println("\t\tPrune, getBounds: " + p.in_getBounds.toMillis() + " milliseconds");
            System.out.println("\t\t\t ... aggregation: " + p.aggTime.toMillis() + " milliseconds");
            System.out.println("\t\t\t ... norm Laplacian: " + p.normLTime.toMillis() + " milliseconds");
            System.out.println("\t\t\t ... finding eigs: " + Prune.solveTime.toMillis() + " milliseconds");
            System.out.println("\t\tPrune, computeVolumes: " + Prune.volTime.toMillis() + " milliseconds");
            System.out.println("\t\tPrune, getNodesInTime: " + p.in_getNodesInTime.toMillis() + " milliseconds");
            System.out.println("\t=-=-=-=-= End timing breakdown =-=-=-=-=");
        }
        this.sizePruned = new boolean[T];
        this.sizeUpdated = new boolean[T];
        this.timePruned = new boolean[T];
        this.timeUpdated = new boolean[T];
    }

    @Override
    public boolean improveEstimate(double e) {
        if (e < this.estimate) {
            this.estimate = e;
            for (int i = 0; i < this.T; ++i) {
                this.sizeUpdated[i] = false;
                this.timeUpdated[i] = false;
            }
            return true;
        }
        return false;
    }

    @Override
    public void updatePruning() {
        int T = this.T;
        List<Integer> list = new ArrayList<>();

        for (int size = 0; size < this.T; ++size) {
            list.add(size);
        }

        /*
        This part consist of pruning
        Here The list of integers are parallelized in rdd

         */
        JavaRDD<Integer> rdd = DynCommDriver.getJsc().parallelize(list);

        /*
        Local Variable to be used by spark
         */
        double [][] bounds = this.bounds;
        double estimate = this.estimate;



        /*
            We are mapping to pair to see which of the size are Pruned
            This computation is being done in parallel
            Finally We are collecting it as Map so that we can use in  next step
         */
        rdd.mapToPair(size -> {
            boolean chop = true;
            int t = 0;
            while (t + size < T) {
                if (bounds[t][size] <= estimate) {
                    chop = false;
                    break;
                }
                ++t;
            }
            return new Tuple2 <>(size, chop);
        }).collectAsMap().forEach((x,y)-> {
            this.sizeUpdated[x] = true;
            this.sizePruned[x] = y;
        });

        /*
            We are mapping to pair to see which of the time are Pruned
            This computation is being done in parallel
            Finally We are collecting it as Map so that we can use in  next step
         */

        rdd.mapToPair(t-> {
            boolean chop = true;
            int size = 0;
            while (t + size < T) {
                if (bounds[t][size] <= estimate) {
                    chop = false;
                    break;
                }
                ++size;
            }
            return new Tuple2 <>(t, chop);
        }).collectAsMap().forEach((x,y) ->{
            this.timeUpdated[x] = true;
            this.timePruned[x] = y;
        });
    }

    @Override
    public boolean isPruned(int ts, int range) {
        int start = ts - range;
        if (start < 0) {
            start = 0;
        }
        for (int s = start; s <= ts; ++s) {
            if (s + range >= this.T) break;
            if (!(this.bounds[s][range] <= this.estimate)) continue;
            return false;
        }
        return true;
    }

    public boolean isPrunedInterval(int ts, int range) {
        return this.bounds[ts][range] > this.estimate;
    }

    @Override
    public boolean isPrunedDuration(int range) {
        if (this.sizeUpdated[range]) {
            return this.sizePruned[range];
        }
        this.sizeUpdated[range] = true;
        if (this.sizePruned[range]) {
            return true;
        }
        int t = 0;
        while (t + range < this.T) {
            if (this.bounds[t][range] <= this.estimate) {
                return false;
            }
            ++t;
        }
        this.sizePruned[range] = true;
        return true;
    }

    @Override
    public void printPruningStats() {
        int total = 0;
        int pruned = 0;
        for (int t = 0; t < this.T; ++t) {
            int d = 0;
            while (t + d < this.T) {
                ++total;
                if (this.isPrunedInterval(t, d)) {
                    ++pruned;
                }
                ++d;
            }
        }
        String perc = String.format("%.4f", 100.0 * ((double)pruned + 0.0) / ((double)total + 0.0));
        System.out.println(pruned + " intervals pruned out of a total of " + total + " (" + perc + "%).");
    }
}

