package org.dcom;/*
 * Decompiled with CFR 0.146.
 */

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;

public class TGraph implements Serializable {
    transient private Logger log;
    private TreeMap<Integer, TreeMap<Integer, TreeMap<Integer, Double>>> adjList;
    private TreeMap<Integer, TreeMap<Integer, TreeMap<Integer, Double>>> timeList;
    private TreeMap<Integer, TreeMap<TreeSet<Integer>, Double>> intList;
    private boolean graphPresent = false;
    private boolean inProgress = false;
    transient private Path graphPath = FileSystems.getDefault().getPath("..", "IO", "new_graph");
    private int numBursts;

    public TGraph() {
        this.log = Logger.getGlobal();
        Random randGen = new Random();
        long randSeed = randGen.nextLong();
        randGen.setSeed(randSeed);
    }

    public TGraph(String g, String m) {
        this();
        this.graphPath = FileSystems.getDefault().getPath(g);
        Path metaPath = FileSystems.getDefault().getPath(m);
    }

    public boolean init(boolean clobber) {
        if (this.graphPresent) {
            if (clobber) {
                this.log.fine("init - clobbering existing graph as directed.");
            } else {
                this.log.warning("init - clobber parameter must be true to dump existing graph!");
                return false;
            }
        }
        this.inProgress = true;
        this.adjList = new TreeMap<>();
        this.timeList = new TreeMap<>();
        this.intList = new TreeMap<>();
        this.numBursts = 0;
        ArrayList<TreeSet<Integer>> burstNodes = new ArrayList<>();
        ArrayList<Integer> burstStartTimes = new ArrayList<>();
        ArrayList<Integer> burstStopTimes = new ArrayList<>();
        this.inProgress = false;
        this.graphPresent = true;
        return true;
    }

    public TreeSet<TemporalNode> tNodes(int t1, int t2) {
        TreeSet<TemporalNode> result = new TreeSet<TemporalNode>();
        for (int i = t1; i < t2; ++i) {
            for (Integer v : this.adjList.keySet()) {
                TemporalNode tn = new TemporalNode(i, v);
                result.add(tn);
            }
        }
        return result;
    }

    public int getNumBursts() {
        return this.numBursts;
    }

    public double normalizeConductance(double phi, int duration) {
        return phi / Math.exp(0.0 * (double)duration);
    }

    public double getIntervalCond(Set<Integer> verts, Integer first, Integer last) {
        double internal = 0.0;
        double external = 0.0;
        double cut = 0.0;
        for ( TreeMap<TreeSet<Integer>, Double>  myMap : this.intList.subMap(first, true, last, true).values()) {
            for (TreeSet pair : myMap.keySet()) {
                double w = myMap.get(pair);
                if (verts.contains(pair.first())) {
                    internal += w;
                    if (verts.contains(pair.last())) {
                        internal += w;
                        continue;
                    }
                    external += w;
                    cut += w;
                    continue;
                }
                external += w;
                if (verts.contains(pair.last())) {
                    internal += w;
                    cut += w;
                    continue;
                }
                external += w;
            }
        }
        return cut / Math.min(internal, external);
    }

    public TreeMap<Integer, Double> getWeightedNeighborhood(TemporalNode tn) {
        int v = tn.getNode();
        int t = tn.getTime();
        return this.timeList.get(v).get(t);
    }

    public boolean addInteraction(int v1, int v2, int t) {
        return this.addInteraction(v1, v2, t, 1.0);
    }

    public boolean addInteraction(int v1, int v2, int t, double w) {
        if (!this.graphPresent && !this.inProgress) {
            this.log.warning("addInteraction - attempted to add to non-existent graph: " + v1 + " " + v2 + " " + t + " " + w);
            return false;
        }
        if (v1 == v2) {
            this.log.warning("addInteraction - attempted to add self-edge: " + v1 + " " + v2 + " " + t + " " + w);
        }
        TreeSet<Integer> pair = new TreeSet<Integer>();
        pair.add(v1);
        pair.add(v2);
        TreeMap<TreeSet<Integer>, Double> intWeight = null;
        intWeight = this.intList.containsKey(t) ? this.intList.get(t) : new TreeMap(new TreeSetComparator());
        double weight = 0.0;
        if (intWeight.containsKey(pair)) {
            weight = intWeight.get(pair);
        }
        intWeight.put(pair, weight + w);
        this.intList.put(t, intWeight);
        TreeMap<Integer, TreeMap<Integer, Double >> thisTime = null;
        thisTime = this.timeList.containsKey(v1) ? this.timeList.get(v1) : new TreeMap();
        TreeMap vertWeight = null;
        vertWeight = thisTime.containsKey(t) ? thisTime.get(t) : new TreeMap();
        weight = 0.0;
        if (vertWeight.containsKey(v2)) {
            weight = (Double)vertWeight.get(v2);
        }
        vertWeight.put(v2, weight + w);
        thisTime.put(t, vertWeight);
        this.timeList.put(v1, thisTime);
        thisTime = this.timeList.containsKey(v2) ? this.timeList.get(v2) : new TreeMap();
        vertWeight = thisTime.containsKey(t) ? thisTime.get(t) : new TreeMap();
        weight = 0.0;
        if (vertWeight.containsKey(v1)) {
            weight = (Double)vertWeight.get(v1);
        }
        vertWeight.put(v1, weight + w);
        thisTime.put(t, vertWeight);
        this.timeList.put(v2, thisTime);
        TreeMap<Integer, TreeMap<Integer, Double >> thisAdj = null;
        thisAdj = this.adjList.containsKey(v1) ? this.adjList.get(v1) : new TreeMap();
        TreeMap timeWeight = null;
        if (thisAdj.containsKey(v2)) {
            timeWeight = thisAdj.get(v2);
        } else {
            timeWeight = new TreeMap();
        }
        weight = 0.0;
        if (timeWeight.containsKey(t)) {
            weight = (Double)timeWeight.get(t);
        }
        timeWeight.put(t, weight + w);
        thisAdj.put(v2, timeWeight);
        this.adjList.put(v1, thisAdj);
        thisAdj = this.adjList.containsKey(v2) ? this.adjList.get(v2) : new TreeMap();
        if (thisAdj.containsKey(v1)) {
            timeWeight = thisAdj.get(v1);
        } else {
            timeWeight = new TreeMap();
        }
        weight = 0.0;
        if (timeWeight.containsKey(t)) {
            weight = (Double)timeWeight.get(t);
        }
        timeWeight.put(t, weight + w);
        thisAdj.put(v1, timeWeight);
        this.adjList.put(v2, thisAdj);
        return true;
    }

    public boolean importGraph(String fileName, boolean oldFormat, boolean oneBasedTime, boolean clobber) {
        if (this.graphPresent) {
            if (clobber) {
                this.log.fine("importGraph - clobbering existing graph as ordered");
            } else {
                this.log.warning("importGraph - attempted to clobber existing graph, failed");
                return false;
            }
        }
        int lineLength = 4;
        Path importPath = this.graphPath;
        if (oldFormat) {
            lineLength = 3;
            this.log.fine("importGraph - reading old file format for file " + fileName);
            importPath = FileSystems.getDefault().getPath("..\\IO\\new_graph");
        }
        int lineNum = 0;
        File graphFile = importPath.resolve(fileName).toFile();
        if (!graphFile.exists() || !graphFile.isFile()) {
            System.err.println("importGraph - Graph file not found: " + graphFile.toString());
            return false;
        }
        try {
            Scanner readG = new Scanner(graphFile);
            readG.nextLine();
            this.graphPresent = false;
            this.inProgress = true;
            this.adjList = new TreeMap();
            this.timeList = new TreeMap();
            this.intList = new TreeMap();
            while (readG.hasNextLine()) {
                int v2;
                int v1;
                ++lineNum;
                String line = readG.nextLine();
                String[] pieces = line.split(",");
                if (pieces.length != lineLength) {
                    this.log.info("importGraph - skipping invalid line " + lineNum + ": " + line);
                    continue;
                }
                if (oldFormat) {
                    try {
                        v1 = Integer.parseInt(pieces[0]);
                        v2 = Integer.parseInt(pieces[1]);
                        Double d = Double.parseDouble(pieces[2]);
                        int t = d.intValue();
                        if (oneBasedTime) {
                            --t;
                        }
                        if (v1 == v2) {
                            this.log.info("importGraph - ignoring self-edge at line " + lineNum + ": " + line);
                            continue;
                        }
                        this.addInteraction(v1, v2, t);
                    }
                    catch (NumberFormatException e) {
                        this.log.info("importGraph - skipping invalid line " + lineNum + ": " + line);
                    }
                    continue;
                }
                try {
                    v1 = Integer.parseInt(pieces[0]);
                    v2 = Integer.parseInt(pieces[1]);
                    int t = Integer.parseInt(pieces[2]);
                    if (oneBasedTime) {
                        --t;
                    }
                    double w = Double.parseDouble(pieces[3]);
                    if (v1 == v2) {
                        this.log.info("importGraph - ignoring self-edge at line " + lineNum + ": " + line);
                        continue;
                    }
                    this.addInteraction(v1, v2, t, w);
                }
                catch (NumberFormatException e) {
                    this.log.info("importGraph - skipping invalid line " + lineNum + ": " + line);
                }
            }
            readG.close();
        }
        catch (FileNotFoundException e) {
            this.log.severe("importGraph - Hit FNF exception in importGraph. Exiting program...");
            System.exit(-1);
        }
        int firstV = this.adjList.firstKey();
        int lastV = this.adjList.lastKey();
        if (firstV != 0 || lastV != this.adjList.size() - 1) {
            System.err.println("ERROR: Vertices not consecutive! firstV = " + firstV + "; lastV = " + lastV + "; num vertices = " + this.adjList.size());
        }
        this.inProgress = false;
        this.graphPresent = true;
        return true;
    }

    public TreeSet<Integer> vertexSet() {
        TreeSet<Integer> result = new TreeSet<Integer>();
        result.addAll(this.adjList.keySet());
        return result;
    }

    public Integer minTime() {
        if (this.intList.keySet().size() == 0) {
            return null;
        }
        return this.intList.firstKey();
    }

    public Integer maxTime() {
        if (this.intList.keySet().size() == 0) {
            return null;
        }
        return this.intList.lastKey();
    }

    public TreeSet<TemporalNode> tNodes(Integer t) {
        TreeSet<TemporalNode> result = new TreeSet<TemporalNode>();
        for (Integer v : this.adjList.keySet()) {
            TemporalNode tn = new TemporalNode(t, v);
            result.add(tn);
        }
        return result;
    }

    public TreeMap standardRWR(Set<Integer> sources, double alpha, boolean byVertex, boolean normalizeByDegree, int t1, int t2) {
        if (sources == null || sources.size() == 0) {
            return null;
        }
        TreeMap<Integer, Double> tempMap = new TreeMap<Integer, Double>();
        for (Integer v : sources) {
            tempMap.put(v, 1.0);
        }
        return this.standardRWR(tempMap, alpha, byVertex, normalizeByDegree, t1, t2);
    }

    public TreeMap standardRWR(TreeMap<Integer, Double> sources, double alpha, boolean byVertex, boolean normalizeByDegree, int t1, int t2) {
        TreeMap<Integer, Double> temp;
        boolean sanity = false;
        int STEPS = 20;
        if (sources == null || sources.size() == 0) {
            return null;
        }
        if (alpha < 0.0 || alpha > 1.0) {
            return null;
        }
        double sumSources = 0.0;
        for (Integer v : sources.keySet()) {
            sumSources += sources.get(v).doubleValue();
        }
        TreeMap<Integer, Double> mass = new TreeMap<Integer, Double>();
        for (Integer v : sources.keySet()) {
            mass.put(v, sources.get(v) / sumSources);
        }
        TreeMap<Integer, Double> wSums = new TreeMap<Integer, Double>();
        for (int step = 0; step < 20; ++step) {
            double value;
            temp = new TreeMap<Integer, Double>();
            for (Integer from : mass.keySet()) {
                int t;
                double weightSum = 0.0;
                if (wSums.containsKey(from)) {
                    weightSum = wSums.get(from);
                } else {
                    for (t = t1; t < t2; ++t) {
                        for (Double w : this.timeList.get(from).get(t).values()) {
                            weightSum += w.doubleValue();
                        }
                    }
                    wSums.put(from, weightSum);
                }
                for (t = t1; t < t2; ++t) {
                    TreeMap<Integer, Double> wMap = this.timeList.get(from).get(t);
                    Iterator iterator = wMap.keySet().iterator();
                    while (iterator.hasNext()) {
                        int to = (Integer)iterator.next();
                        value = temp.containsKey(to) ? temp.get(to) : 0.0;
                        temp.put(to, value += wMap.get(to) * (1.0 - alpha) * (1.0 / weightSum) * mass.get(from));
                    }
                }
            }
            for (Integer v : sources.keySet()) {
                value = temp.containsKey(v) ? temp.get(v) : 0.0;
                temp.put(v, value += alpha * sources.get(v) / sumSources);
            }
            mass = temp;
            if (!sanity) continue;
            double sum = 0.0;
            for (Integer v : mass.keySet()) {
                sum += mass.get(v).doubleValue();
            }
            System.out.println("Step " + step + ": " + sum);
        }
        if (normalizeByDegree) {
            temp = new TreeMap();
            for (Integer v : mass.keySet()) {
                double weightSum = 0.0;
                if (wSums.containsKey(v)) {
                    weightSum = wSums.get(v);
                } else {
                    for (int t = t1; t < t2; ++t) {
                        for (Double w : this.timeList.get(v).get(t).values()) {
                            weightSum += w.doubleValue();
                        }
                    }
                    wSums.put(v, weightSum);
                }
                temp.put(v, mass.get(v) / weightSum);
            }
            mass = temp;
        }
        if (byVertex) {
            return mass;
        }
        TreeMap<Double, Integer> result = new TreeMap<Double, Integer>();
        for (Map.Entry e : mass.entrySet()) {
            double score = (Double)e.getValue();
            while (result.containsKey(score)) {
                score += 1.0E-11;
            }
            result.put(score, (Integer)e.getKey());
        }
        return result;
    }

    public TreeSet<Integer> standardSweeps(TreeMap<Double, Integer> map, double[] conductance, boolean useTC, int t1, int t2) {
        if (map == null || map.size() == 0) {
            return null;
        }
        TreeSet<Integer> result = new TreeSet<Integer>();
        TreeSet<Integer> current = new TreeSet<Integer>();
        Double curKey = map.lastKey();
        result.add(map.get(curKey));
        current.add(map.get(curKey));
        double cut = 0.0;
        for (int t = t1; t < t2; ++t) {
            for (Double w : this.timeList.get(map.get(curKey)).get(t).values()) {
                cut += w.doubleValue();
            }
        }
        double internal = cut;
        double external = 0.0;
        for (TreeMap<TreeSet<Integer>, Double> m : this.intList.subMap(t1, t2).values()) {
            for (Double w : m.values()) {
                external += 2.0 * w;
            }
        }
        external -= internal;
        conductance[0] = 1.0;
        curKey = map.lowerKey(curKey);
        while (curKey != null) {
            int curNode = map.get(curKey);
            for (TreeMap<Integer, Double> m : this.timeList.get(curNode).subMap(t1, t2).values()) {
                for (int v2 : m.keySet()) {
                    Double w = m.get(v2);
                    internal += w.doubleValue();
                    external -= w.doubleValue();
                    if (current.contains(v2)) {
                        cut -= w.doubleValue();
                        continue;
                    }
                    cut += w.doubleValue();
                }
            }
            current.add(curNode);
            double curCond = cut / Math.min(external, internal);
            if (curCond < conductance[0]) {
                conductance[0] = curCond;
                result.addAll(current);
            }
            if (current.size() * 2 > map.size()) break;
            curKey = map.lowerKey(curKey);
        }
        if (useTC) {
            conductance[0] = this.normalizeConductance(conductance[0], t2 - t1);
        }
        return result;
    }

    public TreeMap temporalRWRBeta(Set<TemporalNode> sources, double alpha, double beta, boolean byVertex, boolean normalizeByDegree, boolean bounded) {
        if (sources == null || sources.size() == 0) {
            return null;
        }
        TreeMap<TemporalNode, Double> tempMap = new TreeMap<TemporalNode, Double>();
        for (TemporalNode tn : sources) {
            tempMap.put(tn, 1.0);
        }
        return this.temporalRWRBeta(tempMap, alpha, beta, byVertex, normalizeByDegree, bounded);
    }

    public TreeMap temporalRWRBeta(TreeMap<TemporalNode, Double> sources, double alpha, double beta, boolean byVertex, boolean normalizeByDegree, boolean bounded) {
        TreeMap<TemporalNode, Double> temp;
        boolean sanity = false;
        int STEPS = 10;
        if (sources == null || sources.size() == 0) {
            return null;
        }
        if (alpha < 0.0 || beta < 0.0 || alpha + beta > 1.0) {
            return null;
        }
        double sumSources = 0.0;
        for (TemporalNode tn : sources.keySet()) {
            sumSources += sources.get(tn).doubleValue();
        }
        TreeMap<TemporalNode, Double> mass = new TreeMap<TemporalNode, Double>();
        for (TemporalNode tn : sources.keySet()) {
            mass.put(tn, sources.get(tn) / sumSources);
        }
        Integer[] bounds = bounded ? TemporalNode.span(sources.keySet()) : new Integer[]{this.intList.firstKey(), this.intList.lastKey()};
        if (bounds[0].equals(bounds[1])) {
            beta = 0.0;
        }
        for (int step = 0; step < 10; ++step) {
            double value;
            temp = new TreeMap<TemporalNode, Double>();
            for (TemporalNode from : mass.keySet()) {
                TemporalNode to;
                Integer me = from.getNode();
                int t = from.getTime();
                TreeMap<Integer, Double> myWeightMap = this.timeList.get(me).get(t);
                if (myWeightMap == null || myWeightMap.size() == 0) {
                    value = temp.containsKey(from) ? temp.get(from) : 0.0;
                    temp.put(from, value += (1.0 - beta) * (1.0 - alpha) * mass.get(from));
                } else {
                    int count = 0;
                    for (Integer v2 : myWeightMap.keySet()) {
                        count = (int)((double)count + myWeightMap.get(v2));
                    }
                    for (Integer v2 : myWeightMap.keySet()) {
                        to = new TemporalNode(from.getTime(), v2);
                        value = temp.containsKey(to) ? temp.get(to) : 0.0;
                        temp.put(to, new Double(value += myWeightMap.get(v2) * (1.0 - beta) * (1.0 - alpha) * (1.0 / (double)count) * mass.get(from)));
                    }
                }
                if (!(beta > 0.0)) continue;
                double frac = beta / (double)(bounds[1] - bounds[0]);
                for (int t1 = bounds[0].intValue(); t1 <= bounds[1]; ++t1) {
                    if (t1 == t) continue;
                    to = new TemporalNode(t1, me);
                    value = temp.containsKey(to) ? temp.get(to) : 0.0;
                    temp.put(to, new Double(value += frac * (1.0 - alpha) * mass.get(from)));
                }
            }
            for (TemporalNode tn : sources.keySet()) {
                value = temp.containsKey(tn) ? temp.get(tn) : 0.0;
                temp.put(tn, value += alpha * sources.get(tn) / sumSources);
            }
            mass = temp;
        }
        if (normalizeByDegree) {
            temp = new TreeMap();
            for (TemporalNode tn : mass.keySet()) {
                Integer me = tn.getNode();
                Integer t = tn.getTime();
                TreeMap<Integer, Double> myWeightMap = this.timeList.get(me).get(t);
                if (myWeightMap == null || myWeightMap.size() == 0) {
                    temp.put(tn, mass.get(tn));
                    continue;
                }
                int count = 0;
                for (Integer v2 : myWeightMap.keySet()) {
                    count = (int)((double)count + myWeightMap.get(v2));
                }
                temp.put(tn, mass.get(tn) / (double)count);
            }
            mass = temp;
        }
        if (byVertex) {
            return mass;
        }
        TreeMap<Double, TemporalNode> result = new TreeMap<Double, TemporalNode>();
        for (Map.Entry e : mass.entrySet()) {
            double score = (Double)e.getValue();
            while (result.containsKey(score)) {
                score += 1.0E-11;
            }
            result.put(score, (TemporalNode)e.getKey());
        }
        return result;
    }

    public TreeSet<TemporalNode> AndersenSwipes(TreeMap<Double, TemporalNode> map, double[] conductance, boolean useTC) {
        return this.AndersenAgain(map, conductance, useTC, new PrintStream(new OutputStream(){

            @Override
            public void write(int b) {
            }
        }));
    }

    public TreeSet<TemporalNode> AndersenSwipes(TreeMap<Double, TemporalNode> map, double[] conductance, boolean useTC, String filename, int counter) {
        PrintStream output = null;
        String[] groups = filename.split("\\.");
        String newFileName = groups[0] + "_run" + counter + ".txt";
        try {
            output = new PrintStream("..\\IO\\swiperun\\" + newFileName);
        }
        catch (FileNotFoundException e) {
            System.out.println("AndersenSwipes: ERROR - couldn't open file for writing");
            output = System.out;
        }
        TreeSet<TemporalNode> result = this.AndersenAgain(map, conductance, useTC, output);
        if (!output.equals(System.out)) {
            output.close();
        }
        return result;
    }

    private TreeSet<TemporalNode> AndersenAgain(TreeMap<Double, TemporalNode> map, double[] conductance, boolean useTC, PrintStream output) {
        boolean WEIGHT_MULT = true;
        int MIN_COUNT = 100;
        double RATIO_LIMIT = 1.05;
        TreeSet<TemporalNode> result = null;
        TreeSet<TemporalNode> curSet = new TreeSet<TemporalNode>();
        TreeSet<Integer> extVerts = new TreeSet<Integer>();
        TreeSet<Integer> intVerts = new TreeSet<Integer>();
        Double curKey = map.lastKey();
        TemporalNode curNode = map.get(curKey);
        curSet.add(curNode);
        Integer curVert = curNode.getNode();
        Integer curTime = curNode.getTime();
        extVerts.addAll(this.adjList.keySet());
        extVerts.remove(curVert);
        intVerts.add(curVert);
        Integer loTime = curTime;
        Integer hiTime = curTime;
        double extWeight = 0.0;
        double intWeight = 0.0;
        double cutWeight = 0.0;
        TreeMap<TreeSet<Integer>, Double> myIntList = this.intList.get(loTime);
        for (TreeSet<Integer> pair : myIntList.keySet()) {
            if (pair.contains(curVert)) {
                intWeight += myIntList.get(pair) * 1.0;
                extWeight += myIntList.get(pair) * 1.0;
                continue;
            }
            extWeight += myIntList.get(pair) * 2.0 * 1.0;
        }
        cutWeight = intWeight;
        double bestCond = 1.0;
        result = curSet;
        int counter = 0;
        curKey = map.lowerKey(curKey);
        while (curKey != null) {
            curNode = map.get(curKey);
            curVert = curNode.getNode();
            curTime = curNode.getTime();
            if (curTime < loTime || curTime > hiTime) {
                int start;
                int slices;
                int finish;
                if (curTime < loTime) {
                    slices = loTime - curTime;
                    start = curTime;
                    finish = loTime - 1;
                    loTime = curTime;
                } else {
                    slices = curTime - hiTime;
                    start = hiTime + 1;
                    finish = curTime;
                    hiTime = curTime;
                }
                double tempExternal = 0.0;
                double tempInternal = 0.0;
                double tempCut = 0.0;
                for (int t = start; t <= finish; ++t) {
                    myIntList = this.intList.get(t);
                    for (TreeSet<Integer> pair : myIntList.keySet()) {
                        int v1 = pair.first();
                        int v2 = pair.last();
                        if (intVerts.contains(v1)) {
                            if (intVerts.contains(v2)) {
                                tempInternal += myIntList.get(pair) * 2.0 * 1.0;
                                continue;
                            }
                            tempInternal += myIntList.get(pair) * 1.0;
                            tempExternal += myIntList.get(pair) * 1.0;
                            tempCut += myIntList.get(pair) * 1.0;
                            continue;
                        }
                        if (intVerts.contains(v2)) {
                            tempInternal += myIntList.get(pair) * 1.0;
                            tempExternal += myIntList.get(pair) * 1.0;
                            tempCut += myIntList.get(pair) * 1.0;
                            continue;
                        }
                        tempExternal += myIntList.get(pair) * 2.0 * 1.0;
                    }
                }
                intWeight += tempInternal;
                extWeight += tempExternal;
                cutWeight += tempCut;
            }
            if (extVerts.contains(curVert)) {
                NavigableMap<Integer, TreeMap<Integer, Double>> myTimeList = this.timeList.get(curVert).subMap(loTime, true, hiTime, true);
                for (TreeMap wMap : myTimeList.values()) {
                    for (Object v2 : wMap.keySet()) {
                        intWeight += (Double)wMap.get(v2) * 1.0;
                        extWeight -= (Double)wMap.get(v2) * 1.0;
                        if (intVerts.contains(v2)) {
                            cutWeight -= (Double)wMap.get(v2) * 1.0;
                            continue;
                        }
                        cutWeight += (Double)wMap.get(v2) * 1.0;
                    }
                }
                intVerts.add(curVert);
                extVerts.remove(curVert);
            }
            curSet.add(curNode);
            double curCond = cutWeight / Math.min(intWeight, extWeight);
            if (useTC) {
                int timeslices = hiTime - loTime + 1;
                curCond = this.normalizeConductance(curCond, timeslices);
            }
            if (curCond < bestCond) {
                result = new TreeSet();
                result.addAll(curSet);
                bestCond = curCond;
                output.format("\t%.6f\t%f\t%f\t%f\t%d%n", curCond, cutWeight, intWeight, extWeight, curSet.size());
                counter = 0;
            } else if (++counter > 100 && curCond > bestCond * 1.05) break;
            curKey = map.lowerKey(curKey);
            if (intWeight > extWeight) break;
        }
        conductance[0] = bestCond;
        TreeSet<TemporalNode> inverse = this.tNodes(loTime, hiTime + 1);
        inverse.removeAll(result);
        if (inverse.size() < result.size()) {
            return inverse;
        }
        return result;
    }


}

