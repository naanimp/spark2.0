package org.dcom;

/*
 * Decompiled with CFR 0.146.
 */
public class DummyPruneContainer
extends PruneContainer {
    DummyPruneContainer() {
    }

    @Override
    public boolean improveEstimate(double e) {
        return false;
    }

    @Override
    public void updatePruning() {
    }

    @Override
    public boolean isPruned(int ts, int range) {
        return false;
    }

    @Override
    public boolean isPrunedDuration(int range) {
        return false;
    }

}

