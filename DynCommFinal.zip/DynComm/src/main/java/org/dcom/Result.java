package org.dcom;/*
 * Decompiled with CFR 0.146.
 */
import java.util.Set;

public class Result {
    double normalizedConductance;
    double rawConductance;
    Set<Integer> nodes;
    int startTime;
    int endTime;

    public Result(double normalizedConductance, double rawConductance, Set<Integer> nodes, int startTime, int endTime) {
        this.normalizedConductance = normalizedConductance;
        this.rawConductance = rawConductance;
        this.nodes = nodes;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String toString() {
        return "\nNormalized Conductance:" + this.normalizedConductance + "Raw Conductance: " + this.rawConductance + "\nStart Time: " + this.startTime + " End Time: " + this.endTime + "\nNodes: " + this.nodes;
    }
}

