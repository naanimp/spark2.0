The DynCommDriver.jar file is a runnable JAR file. Run it using
java -jar DynCommDriver.jar

If any command-line arguments are given, these are treated as
the names of input files to use. Otherwise, the program will
read the parameter file and either use the filename specified
there or prompt the user for a filename.

The program looks for params.txt in the same directory as
the JAR file. The details about the various parameters are
listed in that file.

Input files should also be in the same directory. The program
ignores the first line of each input file - we use a human-
readable header line. After that, each line contain four
comma-separated values:
NodeID1, NodeID2, Timestamp, Weight

The assumptions about the input file are as follows:
0) Node IDs and timestamps are non-negative integers.
Weights are non-negative floating-point values.

1) The graph is undirected. Reversing the order of NodeID1
and NodeID2 on a line will not affect the program behavior.
It is assumed that each pair of node IDs appears only once
per timestamp.

2) Timestamps are consecutively numbered starting at zero.
If necessary, times can start from 1 instead by changing
a setting in the parameter file.

3) For best performance, nodes should be consecutively
numbered starting at 0.